<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" dir="ltr">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Design Resources - Calendar and Clock Widgets | DotConcepts - Cleveland/Akron Web Design and Development</title>
  <meta name="blogcatalog" content="9BC9308442" /> 
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="/sites/all/themes/dotconcepts/favicon.ico" type="image/x-icon" />
<meta name="description" content="As a web designer, you get a lot of use out of these top quality open source widgets for producing a variety of different date and time widgets. Whether you're looking for a crisp calendar display, a unique timelines or just want to add functionality for easy date picking, you're bound to find something here that meets your needs." />
<meta name="abstract" content="Free and Open Source Calendar and Clock Widgets for Web Designers and Developers" />
<meta name="keywords" content="website,design,development,graphic,drupal,joomla,wordpress,edirectory,ohio,gravityCMS,expert,free,resources,calendar,clock,widget,opensource" />
<meta name="copyright" content="Copyright 2000 - 2009 DotConcepts.  All rights reserved." />
<link rel="canonical" href="http://www.dotconcepts.net/blog/design-resources-calendar-and-clock-widgets" />
<meta name="revisit-after" content="1 day" />
  <link type="text/css" rel="stylesheet" media="all" href="/modules/acquia/cck/theme/content-module.css?o" />
<link type="text/css" rel="stylesheet" media="all" href="/modules/acquia/filefield/filefield.css?o" />
<link type="text/css" rel="stylesheet" media="all" href="/modules/acquia/img_assist/img_assist.css?o" />
<link type="text/css" rel="stylesheet" media="all" href="/modules/acquia/lightbox2/css/lightbox_alt.css?o" />
<link type="text/css" rel="stylesheet" media="all" href="/modules/acquia/mollom/mollom.css?o" />
<link type="text/css" rel="stylesheet" media="all" href="/modules/acquia/tagadelic/tagadelic.css?o" />
<link type="text/css" rel="stylesheet" media="all" href="/modules/node/node.css?o" />
<link type="text/css" rel="stylesheet" media="all" href="/modules/poll/poll.css?o" />
<link type="text/css" rel="stylesheet" media="all" href="/modules/system/defaults.css?o" />
<link type="text/css" rel="stylesheet" media="all" href="/modules/system/system.css?o" />
<link type="text/css" rel="stylesheet" media="all" href="/modules/system/system-menus.css?o" />
<link type="text/css" rel="stylesheet" media="all" href="/modules/user/user.css?o" />
<link type="text/css" rel="stylesheet" media="all" href="/sites/all/modules/tweetbacks/tweetbacks.css?o" />
<link type="text/css" rel="stylesheet" media="all" href="/modules/acquia/views/css/views.css?o" />
<link type="text/css" rel="stylesheet" media="all" href="/modules/acquia/print/css/printlinks.css?o" />
<link type="text/css" rel="stylesheet" media="all" href="/modules/comment/comment.css?o" />
<link type="text/css" rel="stylesheet" media="all" href="/modules/acquia/comment_notify/comment_notify.css?o" />
<link type="text/css" rel="stylesheet" media="all" href="/sites/all/themes/dotconcepts/html-elements.css?o" />
<link type="text/css" rel="stylesheet" media="all" href="/sites/all/themes/zen/zen/tabs.css?o" />
<link type="text/css" rel="stylesheet" media="all" href="/sites/all/themes/zen/zen/messages.css?o" />
<link type="text/css" rel="stylesheet" media="all" href="/sites/all/themes/zen/zen/block-editing.css?o" />
<link type="text/css" rel="stylesheet" media="all" href="/sites/all/themes/zen/zen/wireframes.css?o" />
<link type="text/css" rel="stylesheet" media="all" href="/sites/all/themes/dotconcepts/layout.css?o" />
<link type="text/css" rel="stylesheet" media="all" href="/sites/all/themes/dotconcepts/dotconcepts.css?o" />
<link type="text/css" rel="stylesheet" media="print" href="/sites/all/themes/dotconcepts/print.css?o" />
<!--[if IE]>
<link type="text/css" rel="stylesheet" media="all" href="/sites/all/themes/zen/zen/ie.css?o" />
<![endif]-->
  <script type="text/javascript" src="/misc/jquery.js?o"></script>
<script type="text/javascript" src="/misc/drupal.js?o"></script>
<script type="text/javascript" src="/modules/acquia/google_analytics/googleanalytics.js?o"></script>
<script type="text/javascript" src="/modules/acquia/img_assist/img_assist.js?o"></script>
<script type="text/javascript" src="/modules/acquia/lightbox2/js/auto_image_handling.js?o"></script>
<script type="text/javascript" src="/modules/acquia/lightbox2/js/lightbox.js?o"></script>
<script type="text/javascript" src="/modules/acquia/mollom/mollom.js?o"></script>
<script type="text/javascript" src="/modules/acquia/comment_notify/comment_notify.js?o"></script>
<script type="text/javascript" src="/misc/textarea.js?o"></script>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
jQuery.extend(Drupal.settings, { "basePath": "/", "googleanalytics": { "trackOutbound": 1, "trackMailto": 1, "trackDownload": 1, "trackDownloadExtensions": "7z|aac|arc|arj|asf|asx|avi|bin|csv|doc|exe|flv|gif|gz|gzip|hqx|jar|jpe?g|js|mp(2|3|4|e?g)|mov(ie)?|msi|msp|pdf|phps|png|ppt|qtm?|ra(m|r)?|sea|sit|tar|tgz|torrent|txt|wav|wma|wmv|wpd|xls|xml|z|zip" }, "lightbox2": { "rtl": 0, "file_path": "/(\\w\\w/)sites/default/files", "default_image": "/modules/acquia/lightbox2/images/brokenimage.jpg", "border_size": 10, "font_color": "000", "box_color": "fff", "top_position": "", "overlay_opacity": "0.8", "overlay_color": "000", "disable_close_click": 1, "resize_sequence": 0, "resize_speed": 400, "fade_in_speed": 400, "slide_down_speed": 600, "use_alt_layout": 1, "disable_resize": 0, "disable_zoom": 0, "force_show_nav": 0, "show_caption": true, "loop_items": 1, "node_link_text": "", "node_link_target": 0, "image_count": "Image !current of !total", "video_count": "Video !current of !total", "page_count": "Page !current of !total", "lite_press_x_close": "press \x3ca href=\"#\" onclick=\"hideLightbox(); return FALSE;\"\x3e\x3ckbd\x3ex\x3c/kbd\x3e\x3c/a\x3e to close", "download_link_text": "", "enable_login": false, "enable_contact": false, "keys_close": "c x 27", "keys_previous": "p 37", "keys_next": "n 39", "keys_zoom": "z", "keys_play_pause": "32", "display_image_size": "original", "image_node_sizes": "(\\.thumbnail)", "trigger_lightbox_classes": "img.inline", "trigger_lightbox_group_classes": "img.thumbnail, img.image-thumbnail", "trigger_slideshow_classes": "", "trigger_lightframe_classes": "", "trigger_lightframe_group_classes": "", "custom_class_handler": 0, "custom_trigger_classes": "", "disable_for_gallery_lists": 1, "disable_for_acidfree_gallery_lists": true, "enable_acidfree_videos": true, "slideshow_interval": 5000, "slideshow_automatic_start": true, "slideshow_automatic_exit": true, "show_play_pause": true, "pause_on_next_click": false, "pause_on_previous_click": true, "loop_slides": false, "iframe_width": 600, "iframe_height": 400, "iframe_border": 1, "enable_video": 0 } });
//--><!]]>
</script>
  <script type="text/javascript">
var domainy = location.protocol == "https:" ? 
"https://leads.demandbase.com" : "http://leads.demandbase.com";
document.write(unescape("%3Cscript src='" +
 domainy +"/254953.js' type='text/javascript'%3E%3C/script%3E"));</script>
<noscript><p>
<img alt="Demandbase Connect" width="1" height="1"
 src="http://leads.demandbase.com/254953ns.gif" />
</p></noscript>
<noscript><p><a href="http://www.demandbase.com">
<img src="http://www.demandbase.com/images/stream/demandbase.gif" 
alt="Demandbase" width="1" height="1"></a></p></noscript>
</head>
<body class="not-front not-logged-in node-type-blog no-sidebars page-blog-design-resources-calendar-and-clock-widgets section-blog">

  <div id="page"><div id="page-inner">

    <a name="top" id="navigation-top"></a>
    
    <div id="header"><div id="header-inner" class="clear-block">

              <div id="logo-title">

                      <div id="logo"><a href="/" title="Home" rel="home"><img src="/sites/all/themes/dotconcepts/logo.png" alt="Home" id="logo-image" /></a></div>
          
          
          
        </div> <!-- /#logo-title -->
            <div id="quote">
        <p style="font-size:28px;color:#003814;font-weight:bold;margin-right:50px;margin-top:15px;background:#cbf1c4;padding:15px 10px;">(330) 983-9455</p>
			</div>
      
    </div></div> <!-- /#header-inner, /#header -->

    <div id="main"><div id="main-inner" class="clear-block">

	<div id="topmenu" class="clear-block">
		<a class="portfolio-link" href="/category/image-galleries/portfolio"></a>
		<a class="services-link" href="/services"></a>
		<a class="blog-link" href="/blog"></a>
		<a class="contact-link" href="/contact"></a>
	</div>

      
      <div class="center"><img id="wrapper-top" src="/sites/all/themes/dotconcepts/images/content-top.png" alt="DotConcepts offers everything you will need to create your web site including quality web design, custom web development and unique graphic design."/></div>
      <div id="content"><div id="content-inner" class="clear-block">

        
        
                  <div id="content-header">
            <div class="breadcrumb"><a href="/">Home</a> › <a href="/blog">Blogs</a> › <a href="/webdesignblog">Michelle Kinney&#039;s blog</a> › </div>                                              </div> <!-- /#content-header -->
        
        <div id="content-area">
          <div id="node-246" class="node node-type-blog"><div class="node-inner">

  
    <h2 class="title">
      <a href="/blog/design-resources-calendar-and-clock-widgets" title="Design Resources - Calendar and Clock Widgets">Design Resources - Calendar and Clock Widgets</a>
    </h2>

  
      <div class="meta">
              <div class="submitted">
          Submitted by <a href="/users/michelle-kinney" title="View user profile.">Michelle Kinney</a> on Fri, 01/22/2010 - 02:11        </div>
      
          </div>
  
  <div class="content">
    <p>As a web designer, you get a lot  of use out of these top quality open source widgets for producing a variety of different date and time widgets.  Whether you're looking for a crisp calendar display, a unique timelines or just want to add functionality for easy date picking, you're bound to find something here that meets your needs.</p>

<p><a href="http://tutorialzine.com/2010/01/advanced-event-timeline-with-php-css-jquery/" alt="Advanced Event Timeline by Tutorialzine">Advanced Event Timeline</a> - A little more complicated than the other widgets here, Tutorialzine put together a walkthrough showing the php, html and jquery necessary to build a custom timeline with clickable events.  Two divs control the functionality; one set to the desired width and the other containing the full display so that users can easily scroll to any area of your timeline.  The php in <a href="http://demo.tutorialzine.com/2010/01/advanced-event-timeline-with-php-css-jquery/demo.php" alt="Adanced Event Timeline Demo">their example</a> is set to pull event by year, but this could easily be adapted to a monthly or even weekly calendar.  All of the elements can be controlled through <a class="zem_slink freebase/en/cascading_style_sheets rdfa" href="http://en.wikipedia.org/wiki/Cascading_Style_Sheets" title="Cascading Style Sheets" rel="ctag:means wikipedia" xmlns:ctag="http://commontag.org/ns#" typeof="ctag:Tag" resource="http://rdf.freebase.com/ns/en/cascading_style_sheets" property="ctag:label">CSS</a> allowing you to seamlessly integrate the timeline into any area of a design.</p>
<span class="inline inline-center"><a href="/category/image-galleries/portfolio/advanced-event-timeline-tutorialzine"><img src="http://dotconcepts.net/sites/default/files/images/advanced-event-timeline.jpg" alt="" title="" class="image image-preview " width="479" height="218"></a></span>
<hr>
<p><a href="http://www.ama3.com/anytime/" alt="Any+Time Date/Time Picker">Any+Time Date/Time Picker</a> - This javascript widget built on the Any+Time Library has more customizations than any date picker we've ever seen.  In addition to fully customizable date/time fields, you can choose which fields to display, place limits on dates, start your week at any day and even accept dates in BC if you ever have the need.  There's also a variety of styling options from the standard css expectations to theming options through jquery Theming, Theme Switcher or Themeroller.  Any+Time also offers an older version for the Prototype library.</p>
<span class="inline inline-center"><a href="/category/image-galleries/portfolio/anytime-datetime-picker"><img src="http://dotconcepts.net/sites/default/files/images/any-time-date-picker.jpg" alt="" title="" class="image image-preview " width="479" height="218"></a></span>
<hr>
<p><a href="http://dev.base86.com/scripts/datepicker_calendar_eightysix.html" alt="Calendar Eightsix">Calendar Eightysix</a> - A lightweight datepicker based on the <a class="zem_slink freebase/en/mootools rdfa" href="http://mootools.net" title="MooTools" rel="ctag:means homepage" xmlns:ctag="http://commontag.org/ns#" typeof="ctag:Tag" resource="http://rdf.freebase.com/ns/en/mootools" property="ctag:label">MooTools</a> framework.  Easy to use and theme, this date picker doesn't require php or ajax to function.  The widget can be customized to start on any day, exclude weekends or holidays, pop-up with an icon or any entry into the field, and even change the language.</p>
<span class="inline inline-center"><a href="/category/image-galleries/portfolio/calender-eightysix"><img src="http://dotconcepts.net/sites/default/files/images/calender-eighty-size-date-picker.jpg" alt="" title="" class="image image-preview " width="479" height="218"></a></span>
<hr>
<p><a href="http://www.clocklink.com" alt="ClockLink">ClockLink</a> - For those times that just call for a good looking clock, ClockLink provides a bevy of flash-based clocks.  Choose from Digital, Analog, Count down, Count up, World clocks and even Transparent options.  You can also change the time zone and display a location of your choice.</p>
<span class="inline inline-center"><a href="/category/image-galleries/portfolio/clocklink-flash-clocks"><img src="http://dotconcepts.net/sites/default/files/images/clocklink-flash-clocks.jpg" alt="" title="" class="image image-preview " width="479" height="218"></a></span>
<hr>
<p><a href="http://www.eyecon.ro/datepicker/" alt="Date Picker jQuery Plugin">Date Picker jQuery Plugin</a> - An excellent solution when your users need to pick a range or two of dates rather than a single day.  Dates can be marked in a variety of ways including weekends, holidays and even your own specials.  Other options include the ability to display multiple months by default, a verity of selection types, localization and CSS customization.</p>
<span class="inline inline-center"><a href="/category/image-galleries/portfolio/date-picker-jquery-plugin"><img src="http://dotconcepts.net/sites/default/files/images/date-picker-jquery.png" alt="" title="" class="image image-preview " width="479" height="162"></a></span>
<hr>
<p><a href="http://www.filamentgroup.com/lab/jquery_interactive_date_range_picker_with_shortcuts" alt="Date Range Picker from Filament Group">Date Range Picker</a> - An update to an already successful date picker, this plugin now uses the latest version of jQuery's datepicker, integrated date.js and added the jQuery CSS Framework classes for easy design changes.  The unique dropdown shortcuts allow users to quickly select a date or range based on your preferences.  The developers are currently working to provide collision detection and better functioning with more than one instance on a page.</p>
<span class="inline inline-center"><a href="/category/image-galleries/portfolio/date-range-picker-jquery"><img src="http://dotconcepts.net/sites/default/files/images/date-ranger-picker-jquery.jpg" alt="" title="" class="image image-preview " width="479" height="218"></a></span>
<hr>
<p><a href="http://dhtmlx.com/docs/products/dhtmlxScheduler/index.shtml" alt="Scheduler from DHTMLX"> dhtmlx Scheduler</a> - Light weight and fast, this fully javascript calendar provides a rich solution for scheduling.  Advanced AJAX functionality allows drag and drop changes to scheduling as well as editing, updates, additions and deletion with no page refreshes.  This script is the front end only requiring either the dhtmlx Connector or your own code to integrate the calender with a server database.    Formats, language and even a Skin Builder give many customization options. dhtmlx also offers this calendar as a module for Joomla and Drupal.</p>
<span class="inline inline-center"><a href="/category/image-galleries/portfolio/dhtmlx-scheduler"><img src="http://dotconcepts.net/sites/default/files/images/dhtmlx-scheduler.jpg" alt="" title="" class="image image-preview " width="479" height="218"></a></span>
<hr>
<p><a href="http://www.stefanoverna.com/log/create-astonishing-ical-like-calendars-with-jquery" alt="iCal Calender">iCal-like jQuery Calender</a> - Using a bit of advanced CSS to achieve the famous Apple styling, this calender was built to provide a lightweight solution for Wordpress implementations.     Rollovers bring up the days events and descriptions and with a bit of back-end coding can be used to allow date editing as well.</p>
<span class="inline inline-center"><a href="/category/image-galleries/portfolio/ical-jquery-calender"><img src="http://dotconcepts.net/sites/default/files/images/ical-jquery-calender.jpg" alt="" title="" class="image image-preview " width="479" height="218"></a></span>
<hr>
<p><a href="http://www.radoslavdimov.com/jquery-plugins/jquery-plugin-digiclock/" alt="jDigiClock by Radoslav Dimov">jDigiClock </a>- Inspired by the HTC Hero Clock Widget, this <a class="zem_slink freebase/en/jquery rdfa" href="http://jquery.com/" title="JQuery" rel="ctag:means homepage" xmlns:ctag="http://commontag.org/ns#" typeof="ctag:Tag" resource="http://rdf.freebase.com/ns/en/jquery" property="ctag:label">jQuery</a> plugin combines a digital clock with a weather display.  Both the clock and the weather aspects are customizable, including the ability to change the clock and weather images, weather location and frequency of weather updates.  jDigiClock requires a source file and stylesheet and is released under both the MIT and <a class="zem_slink freebase/en/gnu_general_public_license rdfa" href="http://en.wikipedia.org/wiki/GNU_General_Public_License" title="GNU General Public License" rel="ctag:means wikipedia" xmlns:ctag="http://commontag.org/ns#" typeof="ctag:Tag" resource="http://rdf.freebase.com/ns/en/gnu_general_public_license" property="ctag:label">GPL</a> licenses.</p>
<span class="inline inline-center"><a href="/category/image-galleries/portfolio/jdigiclock-jquery-clock-and-weather"><img src="http://dotconcepts.net/sites/default/files/images/jDigiClock-weather-clock.jpg" alt="" title="" class="image image-preview " width="480" height="193"></a></span>
<hr>
<p><a href="http://github.com/robmonie/jquery-week-calendar" alt="jQuery Weekly Calender">jQuery Weekly Calender</a> - Inspired by Google Calender, this weekly calender display is incredibly flexible and customizable.  Data can be sent through an array, url or function that returns json.  Events popup in their own windows that can be moved, rearranged and resized.  Calendars can be read-only or editable, display full weeks or only set days and have customizable date formatting.</p>
<span class="inline inline-center"><a href="/category/image-galleries/portfolio/jquery-weekly-calender"><img src="http://dotconcepts.net/sites/default/files/images/jquery-weekly-calendar.jpg" alt="" title="" class="image image-preview " width="479" height="213"></a></span>
<hr>
<p><a href="http://mattbango.com/notebook/web-development/pure-css-timeline/" alt="PureCSS Timeline by Matt Bango">PureCSS Timeline</a> - This simple CSS based timeline degrades easily to an unordered list making it useful for any implementation.  Inline styles are required for placing the items correctly in the space, so CSS purists may find themselves cringing.  Overall an excellent and still basic solution.</p>
<span class="inline inline-center"><a href="/category/image-galleries/portfolio/pure-css-timeline"><img src="http://dotconcepts.net/sites/default/files/images/pure-css-timeline.jpg" alt="" title="" class="image image-preview " width="480" height="143"></a></span>


<fieldset class="zemanta-related"><legend class="zemanta-related-title">Related articles</legend><ul class="zemanta-article-ul"><li class="zemanta-article-ul-li"><a href="http://www.noupe.com/ajax/30-fresh-ajax-tutorials-and-techniques.html">30 Fresh AJAX Tutorials And Techniques</a> (noupe.com)</li><li class="zemanta-article-ul-li"><a href="http://www.smashingmagazine.com/2010/02/01/50-brilliant-css3-javascript-coding-techniques/">50 Brilliant CSS3/JavaScript Coding Techniques</a> (smashingmagazine.com)</li><li class="zemanta-article-ul-li"><a href="http://domainmacher.com/add-pizazz-without-using-flash/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=add-pizazz-without-using-flash">Add Pizazz Without Using Flash</a> (domainmacher.com)</li><li class="zemanta-article-ul-li"><a href="http://woorkup.com/2009/12/27/10-popular-jquery-plugins-in-2009-you-can%25e2%2580%2599t-miss/">10 Popular jQuery Plugins in 2009 You Can't Miss</a> (woorkup.com)</li></ul></fieldset>

<div class="zemanta-pixie" style="margin-top:10px;height:15px"><a class="zemanta-pixie-a" href="http://reblog.zemanta.com/zemified/e0cf165a-35c8-4b53-9755-8224b64b22bb/" title="Reblog this post [with Zemanta]"><img class="zemanta-pixie-img" src="http://img.zemanta.com/reblog_e.png?x-id=e0cf165a-35c8-4b53-9755-8224b64b22bb" alt="Reblog this post [with Zemanta]" style="border:none;float:right"></a><span class="zem-script more-related more-info pretty-attribution"><script type="text/javascript" src="http://static.zemanta.com/readside/loader.js" defer="defer"></script></span></div>  </div>

  <ul class="links inline"><li class="print_html first"><a href="/print/246" title="Display a printer-friendly version of this page." class="print-page" onclick="window.open(this.href); return false" rel="nofollow"><img src="/modules/acquia/print/icons/print_icon.gif" alt="Printer-friendly version" title="Printer-friendly version" width="16" height="16" class="print-icon print-icon-margin" />Printer-friendly version</a></li>
<li class="blog_usernames_blog last"><a href="/webdesignblog" title="Read Michelle Kinney&#039;s latest blog entries.">Michelle Kinney&#039;s blog</a></li>
</ul>  <script type="text/javascript" src="http://w.sharethis.com/button/sharethis.js#publisher=bd89e326-a0ca-4773-90b1-0fc758521014&amp;type=website"></script>
</div></div> <!-- /node-inner, /node -->
  <div id="comments">
          <h2 id="comments-title">Comments</h2>
        <div class="box"><div class="box-inner">

      <h2 class="title">Post new comment</h2>
  
  <div class="content">
    <form action="/comment/reply/246"  accept-charset="UTF-8" method="post" id="comment-form">
<div><div class="form-item" id="edit-comment-wrapper">
 <label for="edit-comment">Comment: <span class="form-required" title="This field is required.">*</span></label>
 <textarea cols="60" rows="15" name="comment" id="edit-comment"  class="form-textarea resizable required"></textarea>
</div>
<ul class="tips"><li>Web page addresses and e-mail addresses turn into links automatically.</li><li>Allowed HTML tags: &lt;a&gt; &lt;em&gt; &lt;strong&gt; &lt;cite&gt; &lt;code&gt; &lt;ul&gt; &lt;ol&gt; &lt;li&gt; &lt;dl&gt; &lt;dt&gt; &lt;dd&gt;</li><li>Lines and paragraphs break automatically.</li></ul><p><a href="/filter/tips">More information about formatting options</a></p><input type="hidden" name="form_build_id" id="form-9d557048c9e18e9fc0d6ed98498449b1" value="form-9d557048c9e18e9fc0d6ed98498449b1"  />
<input type="hidden" name="form_id" id="edit-comment-form" value="comment_form"  />
<input type="hidden" name="mollom[session_id]" id="edit-mollom-session-id" value=""  class="mollom-session-id" />
<div style="display: none;"><div class="form-item" id="edit-mollom-homepage-wrapper">
 <input type="text" maxlength="128" name="mollom[homepage]" id="edit-mollom-homepage" size="60" value="" title="Homepage" autocomplete="off" class="form-text" />
</div>
</div><input type="submit" name="op" id="edit-submit" value="Save"  class="form-submit" />
<input type="submit" name="op" id="edit-preview" value="Preview"  class="form-submit" />

</div></form>
  </div>

</div></div> <!-- /box-inner, /box -->
  </div>
        </div>

        
                <div id="content-right">
          <div id="block-block-4" class="block block-block region-odd odd region-count-1 count-1"><div class="block-inner">

  
  <div class="content">
    <div style="margin-left:20px;">
<a href="http://feeds.feedburner.com/dotconcepts" title="RSS Feed - Follow the Dots" rel="alternate" type="application/rss+xml"><img src="/sites/all/themes/dotconcepts/images/rss.png" alt="Subscribe to our RSS Feed" style="border:0"/></a>
<a href="http://feeds.feedburner.com/dotconcepts"><img src="http://feeds.feedburner.com/~fc/dotconcepts?bg=BCECB1&amp;fg=000000&amp;anim=1" height="26" width="88" style="border:0" alt="" /></a>
<a href="http://twitter.com/dotconcepts" title="Twitter - Tweet with the Dots"><img src="/sites/all/themes/dotconcepts/images/twitter.png" alt="Subscribe to our Twitter Feed" style="border:0"/></a>
<script type="text/javascript" language="JavaScript" src="http://twittercounter.com/embed/dotconcepts/000000/BCECB1"></script>
</div><br/>
<div class="small-bubble"></div>  </div>

  
</div></div> <!-- /block-inner, /block -->
<div id="block-block-5" class="block block-block region-even even region-count-2 count-2"><div class="block-inner">

  
  <div class="content">
    <div id="a-w-web-design" style="width:240px; margin-left:10px;">
<script type="text/javascript" charset="utf-8" src="http://web-design.alltop.com/widget/?type=js"></script>
</div>  </div>

  
</div></div> <!-- /block-inner, /block -->
        </div> <!-- /#sidebar-right-inner, /#sidebar-right -->
      	
        </div><!-- /#content-inner -->

        <div class="center"><img id="wrapper-bottom-top" src="/sites/all/themes/dotconcepts/images/content-bottom-top.png" alt="We are proud that our web design and development efforts have been able to help businesses grow in the Akron area and beyond."/></div>
        <div id="wrapper-bottom" class="clear-block"><div id="block-image-0" class="block block-image region-odd odd region-count-1 count-3"><div class="block-inner">

      <h2 class="title center">Latest Design</h2>
  
  <div class="content">
    <a href="/category/image-galleries/portfolio/radiant-worldwide-media-logo-design"><img src="http://www.dotconcepts.net/sites/default/files/images/radiant-worldwide-logo.thumbnail.jpg" alt="Radiant Worldwide Media Logo Design" title="Radiant Worldwide Media Logo Design"  class="image image-thumbnail " width="185" height="104" /></a>  </div>

  
</div></div> <!-- /block-inner, /block -->
<div id="block-blog-0" class="block block-blog region-even even region-count-2 count-4"><div class="block-inner">

      <h2 class="title center">Recent blog posts</h2>
  
  <div class="content">
    <div class="item-list"><ul><li class="first"><a href="/blog/help-why-was-my-company-or-organizations-wikipedia-article-deleted">Help!  Why was my Company or Organization&#039;s Wikipedia Article Deleted?</a></li>
<li><a href="/blog/questions-ask-yourself-about-using-web-services">Questions to Ask Yourself About Using Web Services</a></li>
<li><a href="/blog/new-drupal-module-audio-field-sox-utility-support">New Drupal Module:  Audio Field with SOX Utility Support</a></li>
<li><a href="/blog/hi-res-textures-rust">Hi-Res Textures: Rust</a></li>
<li><a href="/blog/hi-res-textures-old-barn-and-weathered-material">Hi-Res Textures: Old Barn and Weathered Material</a></li>
<li><a href="/blog/hi-res-textures-nature-bark-and-mottled-ground">Hi-Res Textures: Nature, Bark and Mottled Ground</a></li>
<li><a href="/blog/hi-res-textures-concrete">Hi-Res Textures: Concrete</a></li>
<li><a href="/blog/design-resources-tooltips-and-annotation">Design Resources - Tooltips and Annotation</a></li>
<li><a href="/blog/desktop-wallpapers-valentines-day">Desktop Wallpapers for Valentine&#039;s Day</a></li>
<li class="last"><a href="/blog/design-resources-calendar-and-clock-widgets" class="active">Design Resources - Calendar and Clock Widgets</a></li>
</ul></div><div class="more-link"><a href="/blog" title="Read the latest blog entries.">more</a></div>  </div>

  
</div></div> <!-- /block-inner, /block -->
</div>
        <div id="wrapper-bottom-bottom"><img src="/sites/all/themes/dotconcepts/images/content-bottom-bottom.png" alt="Talk to one of our Project Managers today and let us make your Dot Concepts a Dot Reality."/></div>

      </div> <!-- /#content -->

    </div></div> <!-- /#main-inner, /#main -->

          <div id="footer"><div id="footer-inner" class="region region-footer">

          
        <div id="block-menu-secondary-links" class="block block-menu region-odd odd region-count-1 count-5"><div class="block-inner">

  
  <div class="content">
    <ul class="menu"><li class="leaf first last"><a href="/privacy-policy" title="">Privacy Policy</a></li>
</ul>  </div>

  
</div></div> <!-- /block-inner, /block -->

                  <div id="footer-message">&copy; 2009 DotConcepts; All Rights Reserved.</div>
        
      </div></div> <!-- /#footer-inner, /#footer -->
    
  </div></div> <!-- /#page-inner, /#page -->

  
  <script type="text/javascript">
<!--//--><![CDATA[//><!--
var _gaq = _gaq || [];_gaq.push(["_setAccount", "UA-8831947-1"]);_gaq.push(["_trackPageview"]);(function() {var ga = document.createElement("script");ga.type = "text/javascript";ga.async = true;ga.src = ("https:" == document.location.protocol ? "https://ssl" : "http://www") + ".google-analytics.com/ga.js";var s = document.getElementsByTagName("script")[0];s.parentNode.insertBefore(ga, s);})();
//--><!]]>
</script>

</body>
</html>
