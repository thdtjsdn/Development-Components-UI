<!DOCTYPE html>
<html class="no-js" lang="de-DE" prefix="og: http://ogp.me/ns#">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="profile" href="http://gmpg.org/xfn/11">
  <link rel="dns-prefetch" href="//cache-ssl.celtra.com" />
<link rel="preconnect" href="//cache-ssl.celtra.com" />
<link rel="dns-prefetch" href="//ads.celtra.com" />
<link rel="preconnect" href="//ads.celtra.com" />
<link rel="dns-prefetch" href="//opensource.keycdn.com" />
<link rel="preconnect" href="//opensource.keycdn.com" />
<link rel="dns-prefetch" href="//z.moatads.com" />
<link rel="preconnect" href="//z.moatads.com" />
<link rel="dns-prefetch" href="//sb.scorecardresearch.com" />
<link rel="preconnect" href="//sb.scorecardresearch.com" />
<link rel="dns-prefetch" href="//securepubads.g.doubleclick.net" />
<link rel="preconnect" href="//securepubads.g.doubleclick.net" />
<link rel="dns-prefetch" href="//www.google-analytics.com" />
<link rel="preconnect" href="//www.google-analytics.com" />
<link rel="dns-prefetch" href="//www.googletagservices.com" />
<link rel="preconnect" href="//www.googletagservices.com" />
<link rel="dns-prefetch" href="//adserver.idg.de" />
<link rel="preconnect" href="//adserver.idg.de" />
<link rel="dns-prefetch" href="//www.googletagmanager.com" />
<link rel="preconnect" href="//www.googletagmanager.com" />
<link rel="dns-prefetch" href="//ajax.googleapis.com" />
<link rel="preconnect" href="//ajax.googleapis.com" />
<link rel="dns-prefetch" href="//a.optnmnstr.com" />
<link rel="preconnect" href="//a.optnmnstr.com" />
<link rel="dns-prefetch" href="//pagead2.googlesyndication.com" />
<link rel="preconnect" href="//pagead2.googlesyndication.com" />
<link rel="dns-prefetch" href="//tpc.googlesyndication.com" />
<link rel="preconnect" href="//tpc.googlesyndication.com" />
<link rel="dns-prefetch" href="//static.getclicky.com" />
<link rel="preconnect" href="//static.getclicky.com" />
<link rel="dns-prefetch" href="//auslieferung.commindo-media-ressourcen.de" />
<link rel="preconnect" href="//auslieferung.commindo-media-ressourcen.de" />
<meta name="google-site-verification" content="yQq-bnslN-qaNyEoyGLKyGcghHoDMK3yJYyaLvBItu0" />
<link type="text/css" media="all" href="https://www.drweb.de/magazin/wp-content/cache/autoptimize/css/autoptimize_6e64f4e418b656f0de2479d46faa2664.css" rel="stylesheet" /><link type="text/css" media="only screen and (max-width: 768px)" href="https://www.drweb.de/magazin/wp-content/cache/autoptimize/css/autoptimize_57afcea827824d1db313888418fe13fa.css" rel="stylesheet" /><link type="text/css" media="print" href="https://www.drweb.de/magazin/wp-content/cache/autoptimize/css/autoptimize_6750841479913b0c5d659d7e544a3c9d.css" rel="stylesheet" /><title>jQuery - die interessantesten aktuellen Plugins und Tools - Dr. Web</title>
<script>document.documentElement.className = document.documentElement.className.replace("no-js","js");</script>
<script>(window.gaDevIds=window.gaDevIds||[]).push('5CDcaG');</script>
<!-- This site is optimized with the Yoast SEO Premium plugin v4.9 - https://yoast.com/wordpress/plugins/seo/ -->
<meta name="description" content="jQuery hat sich auf dem weltweiten Markt mit 40 Prozent Anteil zu einer Art Standard entwickelt. Die hohe Verbreitung des Systems führt zu reger Entwicklertätigkeit. In schneller Folge erscheinen nützliche Plugins und Tools, mit denen Sie die Funktionalität Ihrer Websites komfortabel erweitern können. Dr. Web hat sich die interessantesten jQuery-Plugins und -Tools angesehen."/>
<link rel="canonical" href="https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/" />
<link rel="publisher" href="https://plus.google.com/103443335248647770600"/>
<meta property="og:locale" content="de_DE" />
<meta property="og:type" content="article" />
<meta property="og:title" content="jQuery - die interessantesten aktuellen Plugins und Tools - Dr. Web" />
<meta property="og:description" content="jQuery hat sich auf dem weltweiten Markt mit 40 Prozent Anteil zu einer Art Standard entwickelt. Die hohe Verbreitung des Systems führt zu reger Entwicklertätigkeit. In schneller Folge erscheinen nützliche Plugins und Tools, mit denen Sie die Funktionalität Ihrer Websites komfortabel erweitern können. Dr. Web hat sich die interessantesten jQuery-Plugins und -Tools angesehen." />
<meta property="og:url" content="https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/" />
<meta property="og:site_name" content="Dr. Web" />
<meta property="article:publisher" content="https://www.facebook.com/DrWebMagazin" />
<meta property="article:section" content="Webdesign" />
<meta property="article:published_time" content="2010-05-06T11:18:33+02:00" />
<meta property="article:modified_time" content="2016-05-09T11:03:08+02:00" />
<meta property="og:updated_time" content="2016-05-09T11:03:08+02:00" />
<meta property="og:image" content="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/jquery-w500.png" />
<meta property="og:image" content="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/jquery-ui-w500.png" />
<meta property="og:image" content="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/jqt.jpg" />
<meta property="og:image" content="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/easy.jpg" />
<meta property="og:image" content="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/jquerypad.png" />
<meta property="og:image" content="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/microimagegallery-w500.jpg" />
<meta property="og:image" content="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/jsquares.jpg" />
<meta property="og:image" content="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/popeye.jpg" />
<meta property="og:image" content="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/reel.jpg" />
<meta property="og:image" content="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/easyslides.jpg" />
<meta property="og:image" content="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/yoxview.jpg" />
<meta property="og:image" content="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/horinaja-w500.jpg" />
<meta property="og:image" content="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/jphotogrid-w500.jpg" />
<meta property="og:image" content="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/calendarpicker-w500.png" />
<meta property="og:image" content="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/anytime-w500.png" />
<meta property="og:image" content="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/jdigiclock.jpg" />
<meta property="og:image" content="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/charcount-w500.jpg" />
<meta property="og:image" content="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/quicksand.jpg" />
<meta property="og:image" content="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/jeegocontext-w500.png" />
<meta property="og:image" content="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/ketchup-w500.png" />
<meta property="og:image" content="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/chromahash.png" />
<meta property="og:image" content="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/featurelist-w500.png" />
<meta property="og:image" content="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/meerkat-w500.png" />
<meta property="og:image" content="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/tinytips.jpg" />
<meta property="og:image" content="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/spritely.jpg" />
<meta name="twitter:card" content="summary" />
<meta name="twitter:description" content="jQuery hat sich auf dem weltweiten Markt mit 40 Prozent Anteil zu einer Art Standard entwickelt. Die hohe Verbreitung des Systems führt zu reger Entwicklertätigkeit. In schneller Folge erscheinen nützliche Plugins und Tools, mit denen Sie die Funktionalität Ihrer Websites komfortabel erweitern können. Dr. Web hat sich die interessantesten jQuery-Plugins und -Tools angesehen." />
<meta name="twitter:title" content="jQuery - die interessantesten aktuellen Plugins und Tools - Dr. Web" />
<meta name="twitter:site" content="@drwebmagazin" />
<meta name="twitter:image" content="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/jquery-w500.png" />
<meta name="twitter:creator" content="@drwebmagazin" />
<meta property="DC.date.issued" content="2010-05-06T11:18:33+02:00" />
<!-- / Yoast SEO Premium plugin. -->

<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Dr. Web &raquo; Feed" href="https://www.drweb.de/magazin/feed/" />
<link rel="alternate" type="application/rss+xml" title="Dr. Web &raquo; Kommentar-Feed" href="https://www.drweb.de/magazin/comments/feed/" />
<link rel="alternate" type="application/rss+xml" title="Dr. Web &raquo; jQuery &#8211; die interessantesten aktuellen Plugins und Tools Kommentar-Feed" href="https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/feed/" />










<script type='text/javascript' src='https://www.drweb.de/magazin/wp-content/plugins/ah-prism-syntax-highlighter/prism.js'></script>
<script type='text/javascript' src='https://www.drweb.de/magazin/wp-includes/js/jquery/jquery.js'></script>
<script type='text/javascript' src='https://www.drweb.de/magazin/wp-includes/js/jquery/jquery-migrate.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var mailchimp_public_data = {"site_url":"https:\/\/www.drweb.de\/magazin","ajax_url":"https:\/\/www.drweb.de\/magazin\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.drweb.de/magazin/wp-content/plugins/mailchimp-for-woocommerce/public/js/mailchimp-woocommerce-public.min.js'></script>
<script type='text/javascript' src='https://www.drweb.de/magazin/wp-content/plugins/wpdiscuz/assets/third-party/wpdcookiejs/customcookie.js'></script>
<script type='text/javascript' src='https://www.drweb.de/magazin/wp-content/plugins/wpdiscuz/assets/third-party/autogrow/jquery.autogrowtextarea.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wpdiscuzAjaxObj = {"url":"https:\/\/www.drweb.de\/magazin\/wp-admin\/admin-ajax.php","wpdiscuz_options":{"wc_hide_replies_text":"Antworten verbergen","wc_show_replies_text":"Antworten anzeigen","wc_msg_required_fields":"Bitte f\u00fclle alle ben\u00f6tigten Felder aus","wc_invalid_field":"Nicht alle von dir ausgef\u00fcllten Felder sind richtig.","wc_error_empty_text":"Bitte f\u00fclle dieses Feld aus.","wc_error_url_text":"Bitte \u00fcberpr\u00fcfe deine angegebene URL.","wc_error_email_text":"Bitte \u00fcberpr\u00fcfe deine angegebene E-Mail-Adresse.","wc_invalid_captcha":"Leider wurde der CAPTCHA -Code falsch eingetragen","wc_login_to_vote":"Um deine Stimme abgeben zu k\u00f6nnen, musst du angemeldet sein.","wc_deny_voting_from_same_ip":"Es ist nur eine Stimm-Abgabe m\u00f6glich.","wc_self_vote":"Eigene Kommentare k\u00f6nnen nicht bewertet werden.","wc_vote_only_one_time":"Es ist immer nur eine Bewertung erlaubt.","wc_voting_error":"Bewertungs-Fehler bei deiner Wahl: Bitte versuche es erneut","wc_held_for_moderate":"Dein Kommentar wurde zur Freischaltung vorgelegt.","wc_comment_edit_not_possible":"Tut uns leid, aber dieser Kommentar kann leider nicht mehr aktualisiert werden.","wc_comment_not_updated":"Tut uns leid, aber dieser Kommentar konnte leider nicht aktualisiert werden.","wc_comment_not_edited":"Es wurden keine \u00c4nderungen von dir vorgenommen.","wc_new_comment_button_text":"neuer Kommentar","wc_new_comments_button_text":"neue Kommentare","wc_new_reply_button_text":"Neue Antwort auf deinen Kommentar","wc_new_replies_button_text":"Bei einen von dir abonnierten Beitrag wurde eine neue Antwort ver\u00f6ffentlicht.","wc_msg_input_min_length":"Input is too short","wc_msg_input_max_length":"Input is too long","is_user_logged_in":false,"commentListLoadType":"0","commentListUpdateType":"1","commentListUpdateTimer":"30","liveUpdateGuests":0,"wc_comment_bg_color":"#FEFEFE","wc_reply_bg_color":"#F8F8F8","wordpress_comment_order":"asc","commentsVoteOrder":false,"wordpressThreadCommentsDepth":"3","wordpressIsPaginate":"","commentTextMaxLength":null,"storeCommenterData":100000,"isCaptchaInSession":true,"isGoodbyeCaptchaActive":false,"facebookAppID":"","version":"4.0.8","wc_post_id":24263,"loadLastCommentId":"39144","wc_captcha_show_for_guest":"0","wc_captcha_show_for_members":"0","is_email_field_required":"1","confirm":"Are you sure you want to set this comment as","approved":"approved","unapproved":"unapproved","trash":"trashed","spam":"spam","confirm_blacklist":"Are you sure you want to move this user into blacklist","confirm_delete":"Are you sure you want to delete this comment"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.drweb.de/magazin/wp-content/plugins/wpdiscuz/assets/js/wpdiscuz.js'></script>
<script type='text/javascript' src='https://www.drweb.de/magazin/wp-content/plugins/wpdiscuz-frontend-moderation/assets/js/script.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_remove_updated_totals = "0";
/* ]]> */
</script>
<script type='text/javascript' src='https://www.drweb.de/magazin/wp-content/plugins/woocommerce-german-market/js/WooCommerce-German-Market-Frontend.js'></script>
<link rel='https://api.w.org/' href='https://www.drweb.de/magazin/wp-json/' />
<meta name="referrer" content="always"/><style type="text/css">#wpcomm .wc_new_comment{background:#C2272D;}#wpcomm .wc_new_reply{background:#C2272D;}#wpcomm .wc-form-wrapper{background:#F9F9F9;}#wpcomm select,#wpcomm input[type="text"],#wpcomm input[type="email"],#wpcomm input[type="url"],#wpcomm input[type="date"],#wpcomm input[type="color"]{border:#D9D9D9 1px solid;}#wpcomm .wc-comment .wc-comment-right{background:#FEFEFE;}#wpcomm .wc-reply .wc-comment-right{background:#F8F8F8;}#wpcomm .wc-comment-text{font-size:14px;color:#555;}#wpcomm .wc-blog-editor > .wc-comment-right .wc-comment-author,#wpcomm .wc-blog-editor > .wc-comment-right .wc-comment-author a{color:#C2272D;}#wpcomm .wc-blog-editor > .wc-comment-left .wc-comment-label{background:#C2272D;}#wpcomm .wc-blog-administrator > .wc-comment-right .wc-comment-author,#wpcomm .wc-blog-administrator > .wc-comment-right .wc-comment-author a{color:#C2272D;}#wpcomm .wc-blog-administrator > .wc-comment-left .wc-comment-label{background:#C2272D;}#wpcomm .wc-blog-autor > .wc-comment-right .wc-comment-author,#wpcomm .wc-blog-autor > .wc-comment-right .wc-comment-author a{color:#C2272D;}#wpcomm .wc-blog-autor > .wc-comment-left .wc-comment-label{background:#C2272D;}#wpcomm .wc-blog-backwpup_admin > .wc-comment-right .wc-comment-author,#wpcomm .wc-blog-backwpup_admin > .wc-comment-right .wc-comment-author a{color:#C2272D;}#wpcomm .wc-blog-backwpup_admin > .wc-comment-left .wc-comment-label{background:#C2272D;}#wpcomm .wc-blog-backwpup_check > .wc-comment-right .wc-comment-author,#wpcomm .wc-blog-backwpup_check > .wc-comment-right .wc-comment-author a{color:#C2272D;}#wpcomm .wc-blog-backwpup_check > .wc-comment-left .wc-comment-label{background:#C2272D;}#wpcomm .wc-blog-backwpup_helper > .wc-comment-right .wc-comment-author,#wpcomm .wc-blog-backwpup_helper > .wc-comment-right .wc-comment-author a{color:#C2272D;}#wpcomm .wc-blog-backwpup_helper > .wc-comment-left .wc-comment-label{background:#C2272D;}#wpcomm .wc-blog-lektor > .wc-comment-right .wc-comment-author,#wpcomm .wc-blog-lektor > .wc-comment-right .wc-comment-author a{color:#C2272D;}#wpcomm .wc-blog-lektor > .wc-comment-left .wc-comment-label{background:#C2272D;}#wpcomm .wc-blog-subscriber > .wc-comment-right .wc-comment-author,#wpcomm .wc-blog-subscriber > .wc-comment-right .wc-comment-author a{color:#C2272D;}#wpcomm .wc-blog-subscriber > .wc-comment-left .wc-comment-label{background:#C2272D;}#wpcomm .wc-blog-superuser > .wc-comment-right .wc-comment-author,#wpcomm .wc-blog-superuser > .wc-comment-right .wc-comment-author a{color:#C2272D;}#wpcomm .wc-blog-superuser > .wc-comment-left .wc-comment-label{background:#C2272D;}#wpcomm .wc-blog-translator > .wc-comment-right .wc-comment-author,#wpcomm .wc-blog-translator > .wc-comment-right .wc-comment-author a{color:#C2272D;}#wpcomm .wc-blog-translator > .wc-comment-left .wc-comment-label{background:#C2272D;}#wpcomm .wc-blog-post_author > .wc-comment-right .wc-comment-author,#wpcomm .wc-blog-post_author > .wc-comment-right .wc-comment-author a{color:#C2272D;}#wpcomm .wc-blog-post_author > .wc-comment-left .wc-comment-label{background:#C2272D;}#wpcomm .wc-blog-guest > .wc-comment-right .wc-comment-author,#wpcomm .wc-blog-guest > .wc-comment-right .wc-comment-author a{color:#353785;}#wpcomm .wc-blog-guest > .wc-comment-left .wc-comment-label{background:#353785;}#wpcomm .wc-blog-customer > .wc-comment-right .wc-comment-author,#wpcomm .wc-blog-customer > .wc-comment-right .wc-comment-author a{color:#00B38F;}#wpcomm .wc-blog-customer > .wc-comment-left .wc-comment-label{background:#00B38F;}#wpcomm .wc-blog-shop_manager > .wc-comment-right .wc-comment-author,#wpcomm .wc-blog-shop_manager > .wc-comment-right .wc-comment-author a{color:#00B38F;}#wpcomm .wc-blog-shop_manager > .wc-comment-left .wc-comment-label{background:#00B38F;}.wc-load-more-submit{border:1px solid #D9D9D9;}#wpcomm .wc-new-loaded-comment > .wc-comment-right{background:#FFFAD6;}.comments-area{width:auto;}
#wpcomm span{ display: inline !important; }
#wpcomm .wpdiscuz-subscribe-form-button input[type="submit"]:hover, .wc_comm_submit:hover, .mh-footer-nav li a:hover {color: #fff;}.wpdiscuz-front-actions{background:#F9F9F9;}.wpdiscuz-subscribe-bar{background:#F9F9F9;}.wpdiscuz-sort-buttons{color:#bbbbbb;}.wpdiscuz-sort-button{color:#bbbbbb; cursor:pointer;}.wpdiscuz-sort-button:hover{color:#C2272D;cursor:pointer;}.wpdiscuz-sort-button-active{color:#C2272D!important;cursor:default!important;}#wpcomm .page-numbers{color:#555;border:#555 1px solid;}#wpcomm span.current{background:#555;}#wpcomm .wpdiscuz-readmore{cursor:pointer;color:#C2272D;}.wpdiscuz-mod-moderation{background-color:#FFFFFF;border:1px solid #333333;}.wpdiscuz-mod-arrow{border-bottom:9px solid #333333;}.wpdiscuz-mod-arrow-no-border{border-bottom:9px solid #FFFFFF;}.wpdiscuz-mod-moderation-buttons{color:#555;}.wpdiscuz-mod-moderation-buttons span{border-bottom:1px solid #DDDDDD;font-size:14px !important;} #wpcomm .wpdiscuz-textarea-wrap{border:#D9D9D9 1px solid;} .wpd-custom-field .wcf-pasiv-star, #wpcomm .wpdiscuz-item .wpdiscuz-rating > label {color: #DDDDDD;}#wpcomm .wpdiscuz-item .wpdiscuz-rating:not(:checked) > label:hover,.wpdiscuz-rating:not(:checked) > label:hover ~ label {   }#wpcomm .wpdiscuz-item .wpdiscuz-rating > input ~ label:hover, #wpcomm .wpdiscuz-item .wpdiscuz-rating > input:not(:checked) ~ label:hover ~ label, #wpcomm .wpdiscuz-item .wpdiscuz-rating > input:not(:checked) ~ label:hover ~ label{color: #FFED85;} #wpcomm .wpdiscuz-item .wpdiscuz-rating > input:checked ~ label:hover, #wpcomm .wpdiscuz-item .wpdiscuz-rating > input:checked ~ label:hover, #wpcomm .wpdiscuz-item .wpdiscuz-rating > label:hover ~ input:checked ~ label, #wpcomm .wpdiscuz-item .wpdiscuz-rating > input:checked + label:hover ~ label, #wpcomm .wpdiscuz-item .wpdiscuz-rating > input:checked ~ label:hover ~ label, .wpd-custom-field .wcf-activ-star, #wpcomm .wpdiscuz-item .wpdiscuz-rating > input:checked ~ label{ color:#FFD700;} #wpcomm .wc-cta-button:hover{border: 1px solid #C2272D!important; background:#C2272D!important; color:#fff!important;} #wpcomm .wc-cta-active{border: 1px solid #C2272D!important; background:#C2272D!important; color:#fff!important;}#wpcomm .wpf-cta:hover{color:#fff!important; background:#C2272D!important; border:1px solid #C2272D!important;}
        
#wpcomm .wpf-cta{ border: 1px solid #cccccc; color:#bbbbbb; }
#wpcomm .wc-cta-button{ background:#888888; border:1px solid #888888; color:#ffffff;}
#wpcomm .wc-cta-button-x{ background:#888888; border:1px solid #888888; color:#ffffff;}
#wpcomm .wc-vote-link{border:1px solid #bbbbbb; color:#aaaaaa;}
#wpcomm .wc-vote-result{border-top: 1px solid #bbbbbb; border-bottom: 1px solid #bbbbbb; color:#aaaaaa;}
#wpcomm .wc-vote-result.wc-vote-result-like{border:1px solid #bbbbbb;}
#wpcomm .wc-vote-result.wc-vote-result-dislike{border:1px solid #bbbbbb;}
</style>
					<style>
		.gist table {
			margin-bottom: 0 !important;
			table-layout: auto !important;
		}
		.gist .line-numbers
		{
			width: 4em !important;
		}
		.gist .line,
		.gist .line-number
		{
			font-size: 12px !important;
			height: 18px !important;
			line-height: 18px !important;
		}
		.gist .line
		{
			white-space: pre !important;
			width: auto !important;
			word-wrap: normal !important;
		}
		.gist .line span
		{
			word-wrap: normal !important;
		}
		</style>
		<!--[if lt IE 9]>
<script src="https://www.drweb.de/magazin/wp-content/themes/drweb/assets/front/js/ie/html5shiv-printshiv.min.js"></script>
<script src="https://www.drweb.de/magazin/wp-content/themes/drweb/assets/front/js/ie/selectivizr.js"></script>
<![endif]-->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-30413239-1', 'auto');
  ga('require', 'ec'); 
  ga('set', 'anonymizeIp', true);
  ga('send', 'pageview');    
 setTimeout("ga('send','event','Interessierte Nutzer','Mehr als 20 Sekunden')",20000);
</script>    
	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<style type="text/css">
/* Dynamic CSS: For no styles in head, copy and put the css below in your child theme's style.css, disable dynamic styles */
body { font-family: Arial, sans-serif; }
.boxed #wrapper, .container-inner { max-width: 1080px; }
.sidebar .widget { padding-left: 20px; padding-right: 20px; padding-top: 20px; }

.search-expand,
#nav-topbar.nav-container { background-color: #ffffff; }
@media only screen and (min-width: 720px) {
  #nav-topbar .nav ul { background-color: #ffffff; }
}
        

#header { background-color: #ffffff; }
@media only screen and (min-width: 720px) {
  #nav-header .nav ul { background-color: #ffffff; }
}
        

#nav-header.nav-container { background-color: #ffffff; }
@media only screen and (min-width: 720px) {
  #nav-header .nav ul { background-color: #ffffff; }
}
        
#footer-bottom { background-color: #ffffff; }
body { background-color: #ffffff; }
</style>
		<style type="text/css" id="wp-custom-css">
			/*
Hier kannst du dein eigenes CSS einfügen.

Klicke auf das Hilfe-Symbol oben, um mehr zu lernen.

Use this field to test small chunks of CSS code. For important CSS customizations, it is recommended to modify the style.css file of a child theme.
http//codex.wordpress.org/Child_Themes
*/
.boxed #wrapper {margin-top: 0; margin-bottom: 0;}		</style>
	
	<!--Start TN Site Variablen-->
	<script type="text/javascript">
	//GPT-JavaScript-Bibliothek
	(function() {
	var useSSL = 'https:' == document.location.protocol;
	var src = (useSSL ? 'https:' : 'http:') +
	'//www.googletagservices.com/tag/js/gpt.js';
	document.write('<scr' + 'ipt src="' + src + '"></scr' + 'ipt>');
	})();
	//Site-Variablen
	var idgStorage = new Object();
	idgStorage.adUnit1 = "/8456/IDG.DE_NET_Drweb.de";  //statisch alle Seiten
	idgStorage.sec = "article";  //dynamisch home=homepage article=Rest der Seite
	idgStorage.rs_tax = "no_tax";  //statisch alle seiten, wird mit Meta Tag Keywords befuellt,falls vorhanden
</script>
<!--Ende TN Site Variablen-->
<!--Start TN Global Script-->
<script src="//adserver.idg.de/gptjs/tn/tn_dogpt_sync.js" type="text/javascript"></script>
<!--Ende TN Global Script-->
</head>
<body class="post-template-default single single-post postid-24263 single-format-standard wp-custom-logo col-1c boxed topbar-enabled mobile-sidebar-hide chrome">

<div id="ad_leaderboard" class="ad leaderboard" data-ad-zone-id="73" data-ad-visibility="(min-width: 1100px)"></div>

<div id="wrapper">

  <header id="header">
          <nav class="nav-container group" id="nav-topbar">
        <div class="nav-toggle"><i class="fa fa-bars"></i></div>
        <div class="nav-text"><!-- put your mobile menu text here --></div>
        <div class="nav-wrap container"><ul id="menu-oberhalb-header" class="nav container-inner group"><li id="menu-item-82597" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-82597"><a href="https://www.drweb.de/magazin/hier-werben/">Hier werben</a></li>
<li id="menu-item-82596" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-82596"><a href="https://www.drweb.de/magazin/sponsored-post/">Sponsored Post</a></li>
<li id="menu-item-82598" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-82598"><a href="https://www.drweb.de/magazin/kontakt/">Kontakt</a></li>
</ul></div>

        <div class="container">
          <div class="container-inner">
            <div class="toggle-search"><i class="fa fa-search"></i></div>
            <div class="search-expand">
              <div class="search-expand-inner">
                <form method="get" class="searchform themeform" action="https://www.drweb.de/magazin">
	<div>
		<input type="text" class="search" name="s" onblur="if(this.value=='')this.value='Suchbegriff eingeben und Enter drücken';" onfocus="if(this.value=='Suchbegriff eingeben und Enter drücken')this.value='';" value="Suchbegriff eingeben und Enter drücken" />
	</div>
</form>              </div>
            </div>
          </div><!--/.container-inner-->
        </div><!--/.container-->

      </nav><!--/#nav-topbar-->
    
    <div class="container group main-nav">
      <div class="container-inner">
                        
                  <div class="group pad desktop">
            
            <div class="zilla-one-third logo">
            <p class="site-title"><a href="https://www.drweb.de/magazin/" rel="home"><img src="https://www.drweb.de/magazin/wp-content/uploads/2017/03/drweb-logo.png" alt="Dr. Web"></a></p>
<p class="title-image">DrWeb.de</p>
<p class="title-image">Das Magazin für Webworker und Seitenbetreiber.</p>                          </div><!-- .zilla-one-third -->
              
                        <div class="zilla-one-third eins">
            <div class="left-area">   <div class="social-buttons">
                <ul>
                    <li class="social-facebook"><a href="https://www.facebook.com/DrWebMagazin" target="_blank" title="Folge uns auf Facebook" rel="nofollow"><i class="fa fa-facebook"></i></a></li>
                    <li class="social-twitter"><a href="https://twitter.com/drwebmagazin" target="_blank" title="Folge uns auf Twitter" rel="nofollow"><i class="fa fa-twitter"></i></a></li>
                    <li class="social-gplus"><a href="https://plus.google.com/103443335248647770600" target="_blank" title="Folge uns auf Google+" rel="nofollow"><i class="fa fa-google-plus"></i></a></li>

                    <li class="social-rss"><a href="http://feeds.feedburner.com/drwebmagazin" target="_blank" title="Abonniere unseren Feed"><i class="fa fa-rss"></i></a></li>
                    
                    <li class="social-news"><a href="https://www.drweb.de/magazin/newsletter/" target="_blank" title="Abonniere unseren Newsletter"><i class="fa fa-envelope-o"></i></a></li>
               </ul>
    </div>
</div>            </div><!-- .zilla-one-third -->
                        
                         <div class="zilla-one-third drei zilla-column-last">
              
                <div id="search-6" class="widget widget_search"><form method="get" class="searchform themeform" action="https://www.drweb.de/magazin">
	<div>
		<input type="text" class="search" name="s" onblur="if(this.value=='')this.value='Suchbegriff eingeben und Enter drücken';" onfocus="if(this.value=='Suchbegriff eingeben und Enter drücken')this.value='';" value="Suchbegriff eingeben und Enter drücken" />
	</div>
</form></div>            
              </div><!-- .zilla-one-third .zilla-column-last -->
            
          </div>

        
       <!-- Mobile Ansicht -->
                  <nav class="nav-container group" id="nav-header">
            <div class="nav-toggle"><i class="fa fa-bars"></i></div>
            <div class="site-title-mobile"><a href="https://www.drweb.de/magazin/" rel="home"><img src="https://www.drweb.de/magazin/wp-content/uploads/2017/03/drweb-logo.png" alt="Dr. Web"></a></div>            <div class="nav-wrap container">
            <div class="mobile-search"><form method="get" class="searchform themeform" action="https://www.drweb.de/magazin">
	<div>
		<input type="text" class="search" name="s" onblur="if(this.value=='')this.value='Suchbegriff eingeben und Enter drücken';" onfocus="if(this.value=='Suchbegriff eingeben und Enter drücken')this.value='';" value="Suchbegriff eingeben und Enter drücken" />
	</div>
</form></div>
            <ul id="menu-main" class="nav container-inner group"><li id="menu-item-82826" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-has-children menu-item-82826"><a href="https://www.drweb.de/magazin/">Magazin</a>
<ul  class="sub-menu">
	<li id="menu-item-82829" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-82829"><a href="https://www.drweb.de/magazin/wordpress/">WordPress</a>
	<ul  class="sub-menu">
		<li id="menu-item-82845" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82845"><a href="https://www.drweb.de/magazin/wordpress/plugins-wordpress/">Plugins</a></li>
		<li id="menu-item-82846" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82846"><a href="https://www.drweb.de/magazin/wordpress/themes/">Themes</a></li>
		<li id="menu-item-82847" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82847"><a href="https://www.drweb.de/magazin/wordpress/tipps-tricks-tutorials/">Tipps, Tricks &#038; Tutorials</a></li>
	</ul>
</li>
	<li id="menu-item-82827" class="menu-item menu-item-type-taxonomy menu-item-object-category current-post-ancestor current-menu-parent current-post-parent menu-item-82827"><a href="https://www.drweb.de/magazin/webdesign/">Webdesign</a></li>
	<li id="menu-item-82828" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-82828"><a href="https://www.drweb.de/magazin/design/">Design</a>
	<ul  class="sub-menu">
		<li id="menu-item-82848" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-82848"><a href="https://www.drweb.de/magazin/design/bildbearbeitung-vektorgrafiken/">Bilder &#038; Vektorgrafiken bearbeiten</a>
		<ul  class="sub-menu">
			<li id="menu-item-82850" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82850"><a href="https://www.drweb.de/magazin/design/bildbearbeitung-vektorgrafiken/photoshop/">Photoshop</a></li>
			<li id="menu-item-82849" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82849"><a href="https://www.drweb.de/magazin/design/bildbearbeitung-vektorgrafiken/illustrator/">Illustrator</a></li>
			<li id="menu-item-82851" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82851"><a href="https://www.drweb.de/magazin/design/bildbearbeitung-vektorgrafiken/sonstige-programme/">Sonstige Programme</a></li>
		</ul>
</li>
		<li id="menu-item-82852" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82852"><a href="https://www.drweb.de/magazin/design/design-news/">Design-News</a></li>
		<li id="menu-item-82853" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82853"><a href="https://www.drweb.de/magazin/design/editoren/">Editoren</a></li>
		<li id="menu-item-82854" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82854"><a href="https://www.drweb.de/magazin/design/html-css/">HTML/CSS</a></li>
		<li id="menu-item-82855" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82855"><a href="https://www.drweb.de/magazin/design/responsive-design/">Responsive Design</a></li>
	</ul>
</li>
	<li id="menu-item-82830" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-82830"><a href="https://www.drweb.de/magazin/inspiration/">Inspiration</a>
	<ul  class="sub-menu">
		<li id="menu-item-82856" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82856"><a href="https://www.drweb.de/magazin/inspiration/fotografie/">Fotografie</a></li>
		<li id="menu-item-82857" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82857"><a href="https://www.drweb.de/magazin/inspiration/hardware/">Hardware</a></li>
		<li id="menu-item-82858" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82858"><a href="https://www.drweb.de/magazin/inspiration/infografiken/">Infografiken</a></li>
		<li id="menu-item-82859" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82859"><a href="https://www.drweb.de/magazin/inspiration/interviews/">Interviews</a></li>
		<li id="menu-item-82860" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82860"><a href="https://www.drweb.de/magazin/inspiration/quick-shots/">Quick Shots</a></li>
		<li id="menu-item-82861" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82861"><a href="https://www.drweb.de/magazin/inspiration/showcases/">Showcases</a></li>
	</ul>
</li>
	<li id="menu-item-82831" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-82831"><a href="https://www.drweb.de/magazin/essentials/">Essentials</a>
	<ul  class="sub-menu">
		<li id="menu-item-82862" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82862"><a href="https://www.drweb.de/magazin/essentials/services/">(Kostenlose) Services</a></li>
		<li id="menu-item-82863" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82863"><a href="https://www.drweb.de/magazin/essentials/best-of-html-css-psd-ressourcen/">Best-of HTML/CSS/PSD-Ressourcen</a></li>
		<li id="menu-item-82864" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82864"><a href="https://www.drweb.de/magazin/essentials/cartoons/">Cartoons</a></li>
		<li id="menu-item-82865" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82865"><a href="https://www.drweb.de/magazin/essentials/deals-give-aways/">Deals &#038; Give-aways</a></li>
		<li id="menu-item-82866" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82866"><a href="https://www.drweb.de/magazin/essentials/dr-web-newsletter/">Dr. Web Newsletter</a></li>
		<li id="menu-item-82867" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82867"><a href="https://www.drweb.de/magazin/essentials/dr-web-ratgeber/">Dr. Web-Ratgeber</a></li>
		<li id="menu-item-82868" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82868"><a href="https://www.drweb.de/magazin/essentials/exklusiv-bei-drweb/">Exklusiv bei drweb.de</a></li>
		<li id="menu-item-82869" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82869"><a href="https://www.drweb.de/magazin/essentials/freebies-tools-templates/">Freebies, Tools und Templates</a></li>
		<li id="menu-item-82870" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82870"><a href="https://www.drweb.de/magazin/essentials/icons-fonts/">Icons &#038; Fonts</a></li>
		<li id="menu-item-82871" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82871"><a href="https://www.drweb.de/magazin/essentials/links-der-woche/">Links der Woche</a></li>
	</ul>
</li>
	<li id="menu-item-82832" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-82832"><a href="https://www.drweb.de/magazin/e-business/">E-Business</a>
	<ul  class="sub-menu">
		<li id="menu-item-82872" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82872"><a href="https://www.drweb.de/magazin/e-business/betriebliches/">Betriebliches</a></li>
		<li id="menu-item-82873" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82873"><a href="https://www.drweb.de/magazin/e-business/e-commerce-e-business/">E-Commerce</a></li>
		<li id="menu-item-82874" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82874"><a href="https://www.drweb.de/magazin/e-business/freelance/">Freelance</a></li>
		<li id="menu-item-82875" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82875"><a href="https://www.drweb.de/magazin/e-business/online-business-news/">Online-Business-News</a></li>
		<li id="menu-item-82876" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82876"><a href="https://www.drweb.de/magazin/e-business/rechtliches/">Rechtliches</a></li>
		<li id="menu-item-82877" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82877"><a href="https://www.drweb.de/magazin/e-business/seo-online-marketing/">SEO &#038; Online-Marketing</a></li>
		<li id="menu-item-82878" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82878"><a href="https://www.drweb.de/magazin/e-business/social-media/">Social Media</a></li>
		<li id="menu-item-82879" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82879"><a href="https://www.drweb.de/magazin/e-business/technik-e-business/">Technik</a></li>
	</ul>
</li>
	<li id="menu-item-82833" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-82833"><a href="https://www.drweb.de/magazin/programmierung/">Programmierung</a>
	<ul  class="sub-menu">
		<li id="menu-item-82880" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82880"><a href="https://www.drweb.de/magazin/programmierung/apps/">Apps</a></li>
		<li id="menu-item-82881" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82881"><a href="https://www.drweb.de/magazin/programmierung/boilerplates-tools/">Boilerplates &#038; andere Tools</a></li>
		<li id="menu-item-82882" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82882"><a href="https://www.drweb.de/magazin/programmierung/cms/">CMS</a></li>
		<li id="menu-item-82883" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82883"><a href="https://www.drweb.de/magazin/programmierung/developer-news/">Developer-News</a></li>
		<li id="menu-item-82884" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82884"><a href="https://www.drweb.de/magazin/programmierung/fortbildung/">Fortbildung</a></li>
		<li id="menu-item-82885" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82885"><a href="https://www.drweb.de/magazin/programmierung/javascript-jquery/">JavaScript &#038; jQuery</a></li>
		<li id="menu-item-82886" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-82886"><a href="https://www.drweb.de/magazin/programmierung/sonstige-programmiersprachen/">Sonstige Programmiersprachen</a></li>
	</ul>
</li>
</ul>
</li>
<li id="menu-item-82834" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-82834"><a href="https://www.drweb.de/magazin/shop/">Shop</a></li>
<li id="menu-item-82835" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-82835"><a href="https://www.drweb.de/magazin/newsletter/">Newsletter</a></li>
</ul>            </div>
            <!-- Submenu Werbeblock -->
            <div id="ad_submenu" data-ad-zone-id="112" data-ad-visibility="(min-width: 870px)"></div>
          </nav><!--/#nav-header-->
                
        
                <nav class="nav-container-second group" id="nav-below">
        <div class="second-nav-wrap"><ul id="menu-e-books-unter-main" class="nav container-inner group"><li id="menu-item-82836" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-82836"><a href="https://www.drweb.de/magazin/shop/e-book-wordpress-performance/">E-Book: WordPress Performance</a></li>
<li id="menu-item-82837" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-82837"><a href="https://www.drweb.de/magazin/shop/e-book-effektives-online-marketing/">E-Book: Effektives Online Marketing</a></li>
<li id="menu-item-82838" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-82838"><a href="https://www.drweb.de/magazin/shop/e-book-wordpress-sicherheit/">E-Book: WordPress Sicherheit</a></li>
</ul></div>
        </nav>
        
      </div><!--/.container-inner-->
    </div><!--/.container-->
  </header><!--/#header-->
  
  <!-- Billboard Werbung -->
<div id="billboard" data-ad-zone-id="84" data-ad-visibility="(min-width: 1100px)"></div>
<!-- Skyscraper -->
<div id="ad_skyscraper" class="ad skyscraper" data-ad-zone-id="55" data-ad-visibility="(min-width: 1100px)"></div>
 
    <div class="container" id="page">
    <div class="container-inner">
     
      <div class="main">
       
        

        <div class="main-inner group">

<section class="content">

	<div class="page-title pad group">
  			<ul class="meta-single group">
					<li class="comments"><time class="published single" datetime="6. Mai 2010"><i class="fa fa-clock-o"></i>6. Mai 2010</time></li>
			<li class="kategorie"><span class="kategorie"><a href="https://www.drweb.de/magazin/webdesign/">Webdesign</a></span></li>					</ul>

	    
	
</div><!--/.page-title-->
	<div class="pad group">

					<article class="post-24263 post type-post status-publish format-standard hentry category-webdesign">
				<div class="post-inner group">
                <div class="post-title-main-inner">
					<h1 class="post-title entry-title">jQuery &#8211; die interessantesten aktuellen Plugins und Tools</h1>
       
                <div class="mash-top">
                 <div class="total-shares"><i class="fa fa-share-alt"></i><span class="shariff" data-services="totalnumber" data-url="https%3A%2F%2Fwww.drweb.de%2Fmagazin%2Fjquery-die-interessantesten-aktuellen-plugins-und-tools%2F"><span class="shariff-totalnumber">0</span></span></div>
                 <div class="share-buttons"><div class="shariff shariff-main shariff-align-flex-start shariff-widget-align-flex-start shariff-buttonstretch" style="display:none" data-services="facebook%7Ctwitter%7Cgoogleplus%7Cxing" data-url="https%3A%2F%2Fwww.drweb.de%2Fmagazin%2Fjquery-die-interessantesten-aktuellen-plugins-und-tools%2F" data-timestamp="1462791788" data-hidezero="1" data-backendurl="https://www.drweb.de/magazin/wp-json/shariff/v1/share_counts?"><ul class="shariff-buttons theme-color orientation-horizontal buttonsize-medium"><li class="shariff-button facebook" style="background-color:#4273c8"><a href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fwww.drweb.de%2Fmagazin%2Fjquery-die-interessantesten-aktuellen-plugins-und-tools%2F" title="Bei Facebook teilen" aria-label="Bei Facebook teilen" role="button" rel="noopener nofollow" class="shariff-link" target="_blank" style="background-color:#3b5998; color:#fff"><span class="shariff-icon"><svg width="32px" height="20px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 32"><path d="M17.1 0.2v4.7h-2.8q-1.5 0-2.1 0.6t-0.5 1.9v3.4h5.2l-0.7 5.3h-4.5v13.6h-5.5v-13.6h-4.5v-5.3h4.5v-3.9q0-3.3 1.9-5.2t5-1.8q2.6 0 4.1 0.2z"/></svg></span><span class="shariff-text">teilen</span>&nbsp;<span class="shariff-count" data-service="facebook" style="color:#3b5998;opacity:0"></span>&nbsp;</a></li><li class="shariff-button twitter" style="background-color:#32bbf5"><a href="https://twitter.com/share?url=https%3A%2F%2Fwww.drweb.de%2Fmagazin%2Fjquery-die-interessantesten-aktuellen-plugins-und-tools%2F&text=jQuery+%E2%80%93+die+interessantesten+aktuellen+Plugins+und+Tools&via=drwebmagazin" title="Bei Twitter teilen" aria-label="Bei Twitter teilen" role="button" rel="noopener nofollow" class="shariff-link" target="_blank" style="background-color:#55acee; color:#fff"><span class="shariff-icon"><svg width="32px" height="20px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 32"><path d="M29.7 6.8q-1.2 1.8-3 3.1 0 0.3 0 0.8 0 2.5-0.7 4.9t-2.2 4.7-3.5 4-4.9 2.8-6.1 1q-5.1 0-9.3-2.7 0.6 0.1 1.5 0.1 4.3 0 7.6-2.6-2-0.1-3.5-1.2t-2.2-3q0.6 0.1 1.1 0.1 0.8 0 1.6-0.2-2.1-0.4-3.5-2.1t-1.4-3.9v-0.1q1.3 0.7 2.8 0.8-1.2-0.8-2-2.2t-0.7-2.9q0-1.7 0.8-3.1 2.3 2.8 5.5 4.5t7 1.9q-0.2-0.7-0.2-1.4 0-2.5 1.8-4.3t4.3-1.8q2.7 0 4.5 1.9 2.1-0.4 3.9-1.5-0.7 2.2-2.7 3.4 1.8-0.2 3.5-0.9z"/></svg></span><span class="shariff-text">twittern</span>&nbsp;<span class="shariff-count" data-service="twitter" style="color:#55acee;opacity:0"></span>&nbsp;</a></li><li class="shariff-button googleplus" style="background-color:#f75b44"><a href="https://plus.google.com/share?url=https%3A%2F%2Fwww.drweb.de%2Fmagazin%2Fjquery-die-interessantesten-aktuellen-plugins-und-tools%2F" title="Bei Google+ teilen" aria-label="Bei Google+ teilen" role="button" rel="noopener nofollow" class="shariff-link" target="_blank" style="background-color:#d34836; color:#fff"><span class="shariff-icon"><svg width="32px" height="20px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><path d="M31.6 14.7h-3.3v-3.3h-2.6v3.3h-3.3v2.6h3.3v3.3h2.6v-3.3h3.3zM10.8 14v4.1h5.7c-0.4 2.4-2.6 4.2-5.7 4.2-3.4 0-6.2-2.9-6.2-6.3s2.8-6.3 6.2-6.3c1.5 0 2.9 0.5 4 1.6v0l2.9-2.9c-1.8-1.7-4.2-2.7-7-2.7-5.8 0-10.4 4.7-10.4 10.4s4.7 10.4 10.4 10.4c6 0 10-4.2 10-10.2 0-0.8-0.1-1.5-0.2-2.2 0 0-9.8 0-9.8 0z"/></svg></span><span class="shariff-text">teilen</span>&nbsp;<span class="shariff-count" data-service="googleplus" style="color:#d34836;opacity:0"></span>&nbsp;</a></li><li class="shariff-button xing" style="background-color:#29888a"><a href="https://www.xing.com/social_plugins/share?url=https%3A%2F%2Fwww.drweb.de%2Fmagazin%2Fjquery-die-interessantesten-aktuellen-plugins-und-tools%2F" title="Bei Xing teilen" aria-label="Bei Xing teilen" role="button" rel="noopener nofollow" class="shariff-link" target="_blank" style="background-color:#126567; color:#fff"><span class="shariff-icon"><svg width="32px" height="20px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 25 32"><path d="M10.7 11.9q-0.2 0.3-4.6 8.2-0.5 0.8-1.2 0.8h-4.3q-0.4 0-0.5-0.3t0-0.6l4.5-8q0 0 0 0l-2.9-5q-0.2-0.4 0-0.7 0.2-0.3 0.5-0.3h4.3q0.7 0 1.2 0.8zM25.1 0.4q0.2 0.3 0 0.7l-9.4 16.7 6 11q0.2 0.4 0 0.6-0.2 0.3-0.6 0.3h-4.3q-0.7 0-1.2-0.8l-6-11.1q0.3-0.6 9.5-16.8 0.4-0.8 1.2-0.8h4.3q0.4 0 0.5 0.3z"/></svg></span><span class="shariff-text">teilen</span>&nbsp;<span class="shariff-count" data-service="xing" style="color:#126567;opacity:0"></span>&nbsp;</a></li><li class="shariff-button mailform" style="background-color:#a8a8a8"><a href="https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/?view=mail#shariff_mailform" title="Per E-Mail versenden" aria-label="Per E-Mail versenden" role="button" rel="noopener nofollow" class="shariff-link" style="background-color:#999; color:#fff"><span class="shariff-icon"><svg width="32px" height="20px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><path d="M32 12.7v14.2q0 1.2-0.8 2t-2 0.9h-26.3q-1.2 0-2-0.9t-0.8-2v-14.2q0.8 0.9 1.8 1.6 6.5 4.4 8.9 6.1 1 0.8 1.6 1.2t1.7 0.9 2 0.4h0.1q0.9 0 2-0.4t1.7-0.9 1.6-1.2q3-2.2 8.9-6.1 1-0.7 1.8-1.6zM32 7.4q0 1.4-0.9 2.7t-2.2 2.2q-6.7 4.7-8.4 5.8-0.2 0.1-0.7 0.5t-1 0.7-0.9 0.6-1.1 0.5-0.9 0.2h-0.1q-0.4 0-0.9-0.2t-1.1-0.5-0.9-0.6-1-0.7-0.7-0.5q-1.6-1.1-4.7-3.2t-3.6-2.6q-1.1-0.7-2.1-2t-1-2.5q0-1.4 0.7-2.3t2.1-0.9h26.3q1.2 0 2 0.8t0.9 2z"/></svg></span><span class="shariff-text">E-Mail</span>&nbsp;</a></li></ul></div></div>
                 <div class="clear"></div>
             </div>
         
                    
                      
             <div class="post-format">
        <div class="image-container zilla-two-third">
            <img class="placeholder" src="https://www.drweb.de/magazin/wp-content/themes/drweb/images/placeholder-middle.jpg" alt="Kein Beitragsbild" />        </div>
        <div class="author-ad zilla-one-third zilla-column-last">
            <div class="author-bio-small">
<div class="bio-avatar-small"><img alt='' src='https://secure.gravatar.com/avatar/2d124df6c46d7b60abba7f1e809ee6e2?s=100&#038;d=identicon&#038;r=pg' srcset='https://secure.gravatar.com/avatar/2d124df6c46d7b60abba7f1e809ee6e2?s=200&amp;d=identicon&amp;r=pg 2x' class='avatar avatar-100 photo' height='100' width='100' /></div>
<div class="author-inner small">
<p class="bio-name-small"><a class="author-name-small" href="https://www.drweb.de/magazin/author/dieter-petereit/">Dieter Petereit</a></p>
 <p class="author-desc">ist seit 1994 im Netz unterwegs, aber bereits seit über 30 Jahren... <a href="https://www.drweb.de/magazin/author/dieter-petereit/" title="Weiterlesen"><i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i></a></p></div>
<div class="clear"></div>
</div>   
                                    <div class="ad-widget-thumb">			<div class="textwidget"><div id="ad_medium_rectangle" class="ad" data-ad-zone-id="17" data-ad-visibility="screen and (min-width: 300px)"></div></div>
		</div>                        			<div class="sidebar">
				<div class="widget-aside"><div class="news-aside">
<h3 class="widget-title">Newsletter Abonnieren</h3>
<p>Melde dich für unseren Newsletter an und du bekommst gratis zwei E-Books dazu. Zudem warten nützliche Ressourcen und gute Tipps auf dich.</p>
<div id="mc_embed_signup" class="mailchimp-signup-form">
<form action="//drweb.us1.list-manage.com/subscribe/post?u=1909951713873d746b1e007b0&amp;id=af0fbc3456" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate">
    <div id="mc_embed_signup_scroll">
	<input type="email" value="" name="EMAIL" class="email" id="mce-EMAIL" placeholder="Deine E-Mail-Adresse" required>
	<input type="text" value="" name="FNAME" class="email" id="mce-FNAME" placeholder="Dein Name (optional)">
	<input type="hidden" name="KAMPAGNE" value="'.(isset($atts['default_campaign']) ? esc_attr($atts['default_campaign']) : "").'">
	<!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
    <div style="position: absolute; left: -5000px;"><input type="text" name="b_1909951713873d746b1e007b0_af0fbc3456" tabindex="-1" value=""></div>
    <div class="clear"></div>
    <center><input type="submit" value="Eintragen" name="subscribe" id="mc-embedded-subscribe" class="button"></center>
    </div>
</form>
</div>
</div>
</div><div class="widget-aside"><h3 class="widget-title">Soschel mit uns</h3>   <div class="social-buttons">
                <ul>
                    <li class="social-facebook"><a href="https://www.facebook.com/DrWebMagazin" target="_blank" title="Folge uns auf Facebook" rel="nofollow"><i class="fa fa-facebook"></i></a></li>
                    <li class="social-twitter"><a href="https://twitter.com/drwebmagazin" target="_blank" title="Folge uns auf Twitter" rel="nofollow"><i class="fa fa-twitter"></i></a></li>
                    <li class="social-gplus"><a href="https://plus.google.com/103443335248647770600" target="_blank" title="Folge uns auf Google+" rel="nofollow"><i class="fa fa-google-plus"></i></a></li>

                    <li class="social-rss"><a href="http://feeds.feedburner.com/drwebmagazin" target="_blank" title="Abonniere unseren Feed"><i class="fa fa-rss"></i></a></li>
                    
                    <li class="social-news"><a href="https://www.drweb.de/magazin/newsletter/" target="_blank" title="Abonniere unseren Newsletter"><i class="fa fa-envelope-o"></i></a></li>
               </ul>
    </div>
</div><div class="widget-aside"><h3 class="widget-title">Unsere E-Books für dich</h3>			<div class="textwidget"><p><a href="https://goo.gl/Zs0mKB"><img src="https://www.drweb.de/magazin/wp-content/uploads/2017/01/wp-performance-cover-small.png" alt="E-Book WordPress Performance" /></a></p>
<p><a href="https://goo.gl/ieNuWM"><img src="https://www.drweb.de/magazin/wp-content/uploads/2017/01/wp-sicherheit-cover-small.png" alt="E-Book WordPress Sicherheit" /></a></p>
</div>
		</div>    
			</div>

        </div>
    </div>					</div><!-- end .post-title-main-inner -->

					<div class="clear"></div>
                    
					<div class="entry themeform">
					 <div class="zilla-two-third" id="artikel">
						<div class="entry-inner">
							<p class="opener"><strong>jQuery</strong><strong> wurde zu Beginn des Jahres 2010 auf die Versionsnummer 1.4 gehoben. Heute aktuell ist die Version 1.4.2. Auf dem weltweiten Markt hat sich jQuery mit 40 Prozent Anteil zu einer Art Standard entwickelt, dem sich in Deutschland lediglich noch die global bedeutungslosen Mootools nähern können. Die hohe Verbreitung des Systems führt zu reger Entwicklertätigkeit rund um die Erweiterung der Funktionalitäten. In schneller Folge erscheinen Plugins und Tools. Dr. Web hat sich die Interessantesten angesehen.</strong></p>
<p><img class="ngg-singlepic ngg-none" src="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/jquery-w500.png" alt="jquery-w500.png" width="260" height="88" /></p>
<h4>Noch ein Wort zu Mootools</h4>
<p>Da im Grunde die <strong>Entscheidung</strong> über den Einsatz eines Javascript-Frameworks <strong>zwischen jQuery</strong> und <strong>Mootools</strong> fallen dürfte, empfehle ich <a id="yh75" title="diesen sehr ausführlichen Beitrag" href="http://jqueryvsmootools.com/">diesen sehr ausführlichen Beitrag</a> von (Mootools-Entwickler) Aaron Newton. Newton gibt Einblicke in die <strong>unterschiedlichen Ansätze der Systeme</strong> und vergleicht sie miteinander. Im Ergebnis erklärt er beide zur richtigen Wahl, wobei der <strong>Fokus bei jQuery</strong> mehr auf der <strong>Entwicklungsgeschwindigkeit</strong> und der <strong>schnellen Einsetzbarkeit</strong> liegt. <strong>Mootools erfordert höheren Einarbeitungsaufwand</strong> und ist eher für den &#8220;echten&#8221; Programmierer, weniger für den Brot-und-Butter-Dienstleister interessant ist.</p>
<h3>jQueryUI und jQueryTools &#8211; für die schnelle (Web)User-Interface-Entwicklung</h3>
<p><img class="ngg-singlepic ngg-none" src="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/jquery-ui-w500.png" alt="jquery-ui-w500.png" /></p>
<p>Natürlich kann sich jeder mit entsprechendem Verständnis des <a id="d6jx" title="jQuery-Framework" href="http://jquery.com/">jQuery-Framework</a> seine eigenen User Interfaces (UI), sprich <strong>Benutzerschnittstellen</strong>, zusammen schrauben. Einfacher macht man es sich durch die Verwendung einer auf UI-Aspekte spezialisierten Funktionsbibliothek.</p>
<h4>jQueryUI</h4>
<p>Der bekannteste und <strong>umfangreichste Vertreter</strong> seiner Art dürfte dabei das Open Source-Projekt <a id="w7d_" title="jQueryUI" href="http://jqueryui.com">jQueryUI</a> sein. Neben vielen anspruchsvollen <a id="il2_" title="Effekten und Interfacewidgets" href="http://jqueryui.com/demos/">Effekten und Interfacewidgets</a> bietet es ein <a id="zat4" title="professionelles Theme-Framework" href="http://jqueryui.com/themeroller/">professionelles Theme-Framework</a> mit einer <strong>Vielfalt vorhandener Themes</strong> im aktuellen Design-Standard. jQueryUI sollten nicht nur jQuery-Einsteiger einer genaueren Betrachtung unterziehen. Aktuell ist die Version 1.8.1 für jQuery ab 1.4.</p>
<p><strong>Tipp</strong>: Wer noch die ältere 1.3+ von jQuery nutzt, muss darauf achten, die Version 1.7.3 der jQueryUI herunter zu laden.</p>
<h4>jQueryTools</h4>
<p>Weit weniger voluminös hinsichtlich der bereitgestellten Funktionen präsentiert sich das Open Source-Projekt jQueryTools. Die j<strong>QueryTools</strong> (JQT) verzichten auf viele aus dem jQueryUI bekannte Funktionen und <strong>konzentrieren sich</strong> stattdessen auf das reine <strong>&#8220;Aufpeppen&#8221; konventioneller Websites</strong>. Die Tools sind entsprechend nicht zur Programmierung von echten Web-2-Diensten, wie Webmailclients oder ähnlichem gedacht. Für solche Anforderungen eignet sich jQueryUI weitaus besser.</p>
<p><img class="ngg-singlepic ngg-none" src="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/jqt.jpg" alt="jqt.jpg" /></p>
<p><strong>jQueryTools wendet sich an HTML-Entwickler</strong>, die <strong>nach Fertigstellung eines Projekte</strong>s die ein oder andere <strong>Funktionalität</strong> unter Einsatz von jQuery <strong>verbessern</strong> möchten. Damit stellen die Tools eine gedanklich andere Herangehensweise dar. jQuery-Kenntnisse sind für den Einsatz der Tools nicht erforderlich, wenn auch natürlich stets nützlich.</p>
<p>Die Entwickler behaupten, die wichtigsten Komponenten im User Interface heutiger Websites abzudecken. Es gibt Lösungen für Tabs, Tooltips, Overlays, Exposés und scrollbare Bereiche. In der aktuellen, soeben erst erschienenen Version 1.2 wurden HTML5-basierende Formulartools hinzugefügt, deren Funktionalitäten teilweise selbst bei abgeschaltetem Javascript zur Verfügung stehen.</p>
<p>Bei einer <strong>Gesamtgröße</strong> von knapp <strong>10 kb</strong> und einer klaren Fokussierung auf Standardwebsites können die JQT in vielen Fällen das <strong>Mittel der Wahl für den Durchschnittsauftrag</strong> darstellen. Einen tieferen Einstieg in JQT erhalten Sie in unserem <a id="oztp" title="Tochtermagazin Noupe" href="http://www.noupe.com/jquery/jquery-tools.html">Tochtermagazin Noupe</a>.</p>
<div class="intra-content-ad" id="intra-content-ad" data-ad-zone-id="96"></div><h3>Easy Frontend Framework &#8211; beschleunigte Frontend-Entwicklung</h3>
<p><img class="ngg-singlepic ngg-none" src="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/easy.jpg" alt="easy.jpg" /></p>
<p><a id="e-b5" title="Easy" href="http://easyframework.com/">Easy</a> ist ein <strong>Framework für HTML, CSS und Javascript</strong>. Es integriert jQuery und setzt auf dessen Funktionalitäten auf. Da es sich sowohl um <strong>Struktur</strong>, wie auch <strong>Präsentation</strong> und <strong>Interaktivität</strong> kümmert, bildet es alle drei relevanten Kernbereiche der Entwicklung einer Website ab.</p>
<p>Mittels Easy lässt sich ein <strong>Mastertemplate</strong> für das nächste Webprojekt rationell und schnell entwickeln. Soweit man die enthaltenen jQuery-Funktionalitäten verwendet, sind keine Javascript-Kenntnisse vonnöten.</p>
<h4>Ergänzbare Framework-Bibliothek</h4>
<p>Fortgeschrittene Entwickler wird freuen, dass sich die Framework-Bibliothek um eigenen Code ergänzen lässt, so dass sich ein jeder seine eigene Entwicklungsumgebung schaffen kann. <a id="c_n1" title="Anschauen" href="http://easyframework.com/demo.php"><strong>Anschauen</strong></a> sollten Sie sich Easy auf jeden Fall.</p>
<h3>jQueryPad &#8211; Codeeditor für den Offline-Test</h3>
<p><img class="ngg-singlepic ngg-none" src="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/jquerypad.png" alt="jquerypad.png" /></p>
<p>Das <a id="behs" title="jQueryPad" href="http://www.paulstovell.com/jquerypad">jQueryPad</a> von Paul Stovell ermöglicht neben der Kernfunktionalität eines <strong>Codeeditors für HTML und Jacascript</strong> das <strong>Offlinetesten von jQuery-Code</strong>. Hierzu referenziert es jQuery.js im eigenen Templateverzeichnis. Die Verwendung einer bestimmten jQuery-Version erfolgt daher einfach durch Austausch der entsprechenden Bibliothek.</p>
<p>jQueryPad nutzt <strong>WPF aus dem .NET Framework</strong> 3.5 SP 1 und ist daher <strong>auf Windows beschränk</strong>t, bedarf aber immerhin dort keiner Installation; eine erfreuliche Seltenheit unter dem Betriebssystem aus Redmond. Der Test der jQuery-Funktionen wird unter Einbindung der Web Browser Control mit dem Internet Explorer realisiert.</p>
<h4>Browser-Kompatibilität</h4>
<p>HTML-Tests können, je nach installiertem Browserumfeld, unter <strong>IE, Chrome </strong>oder <strong>Firefox</strong> stattfinden. Zumindest in meinem Kurztest konnten Safari und Opera nicht eingebunden werden.</p>
<p>jQueryPad steht ausschließlich in englischer Sprache bereit und kann <strong>kostenlos</strong> herunter geladen und verwendet werden.</p>
<h3>Plugins mit Bezug zur Bildpräsentation</h3>
<h4>Micro Image Gallery (MIG)</h4>
<p><a href="http://tympanus.net/Tutorials/MicroGalleryImproved/" target="_self"><img class="ngg-singlepic ngg-none" src="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/microimagegallery-w500.jpg" alt="microimagegallery-w500.jpg" /></a></p>
<p>Wollen Sie Bilder in Websites integrieren, in denen der <strong>Fokus auf den Texten</strong> liegt, wie es zum Beispiel auf Newssites der Fall ist, und wollen Sie dementsprechend den Bildern keine großen Flächen widmen, kommt <a id="k67d" title="MIG" href="http://tympanus.net/codrops/2010/04/26/improved-micro-image-gallery-a-jquery-plugin/">MIG</a> für Sie in Frage. Mit diesem jQuery-Plugin legen Sie <strong>miniaturisierte Bildergallerien</strong> an, die bestens als <strong>Support zu aktuellen Nachrichten</strong> dienen können. Die erzeugte Gallerie lässt sich in drei Größen darstellen, wobei die größte Größe einer maximalen Höhe und Breite von 222 Pixeln entspricht. Sie sehen schon, dass sich ein Fotografenportfolio so eher nicht umsetzen lässt. Entsprechend der Zielstellung genutzt, ist MIG jedoch ein elegantes, modernes und leichtgewichtiges Galleriesystem. <a id="zxxl" title="Hier entlang" href="http://tympanus.net/Tutorials/MicroGalleryImproved/">Hier entlang</a> geht es zu den Beispielen &#8230;</p>
<h4>jSquares for jQuery</h4>
<p><span class="removed_link" title="http://boedesign.com/demos/jsquares/"><img class="ngg-singlepic ngg-none" src="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/jsquares.jpg" alt="jsquares.jpg" /></span></p>
<p>Eine andere Art der Bildpräsentation ermöglicht das Plugin <span class="removed_link" title="http://boedesign.com/blog/2009/10/22/jsquares-for-jquery/">jSquares</span>. Hier werden, ähnlich einer <strong>Collage</strong>, Bilder in einem Grid angeordnet. Hovert der Nutzer mit der Maus über die einzelnen Bilder, wird ein Overlay mit dem Bild begleitenden Texten angezeigt, während das Element gleichzeitig hervorgehoben erscheint und die übrigen Bilder abgeblendet werden. Zur Demo geht es <span class="removed_link" title="http://boedesign.com/demos/jsquares/">hier entlang</span>&#8230;</p>
<h4>jQuery.popeye 2.0</h4>
<p><img class="ngg-singlepic ngg-none" src="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/popeye.jpg" alt="popeye.jpg" /></p>
<p>Popeye ist ein Galleryscript und dabei zuvorderst eine <strong>Alternative zu den bekannten Lightbox-Lösungen</strong>, wie Lightbox, Fancybox, Shadowbox oder Thickbox.</p>
<p>Anders als die genannten Lösungen, öffnet Popeye kein Overlay im Zentrum der Website zur Präsentation des Bildes. Vielmehr <strong>belässt Popeye die Bilder</strong> an den eingebetteten Position <strong>im Textflow</strong> und <strong>vergrößert sie auf Klick</strong> auch von dieser Position aus. So wird der Nutzer nicht aus seinem Lesefluss gerissen. Die hinterliegende Gallerie kann ohne Vergrößerung angesehen werden, wobei jedem Bild in einem weiteren Overlay Informationen beigegeben werden können.</p>
<p>Wenn es nicht ausdrücklich um die Präsentation von Fotos oder Screenshots allgemeiner Portfolios geht, ist Popeye die klar bessere Alternative! Überzeugen Sie sich selbst anhand dieser Demo&#8230;</p>
<p><strong>Bonus</strong>: Popeye gibt es auch als <a id="g6:q" title="Wordpress-Plugin" href="http://wordpress.org/extend/plugins/popeye/">WordPress-Plugin</a>.</p>
<h4>jQuery.Reel</h4>
<p><a href="http://jquery.vostrel.cz/reel" target="_self"><img class="ngg-singlepic ngg-none" src="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/reel.jpg" alt="reel.jpg" /></a></p>
<p>Vor über 10 Jahren nutzte ich Java, um den Eindruck von <strong>3D-Präsentationen</strong> zu schaffen. In erster Linie ging es darum, fotografierte Objekte um die komplette Achse rotieren und dabei betrachten zu können oder darum, Panoramen spektakulärer Orte, wie Urlaubshotels und Berggipfel online zu bringen. Ab etwa dem Jahr 2000 übernahm Flash diese Domäne.</p>
<p>Mit <a id="ejhi" title="Reel" href="http://jquery.vostrel.cz/reel">Reel</a> steht ein jQuery-Plugin zur Verfügung, dass genau diesen Einsatzzweck komplett <strong>ohne Jar und Flash</strong> abzudecken weiss. Dabei ist die Vorgehensweise fast identisch zur dunnemaligen Javapräsentation. Grundlage ist stets eine einzelne Bilddatei. Für eine <strong>360-Grad-Rotation</strong> eines Objektes fotografiert man das Objekt bis zur Idealzahl von 36 Frames. Diese werden dann in einem Grid zu einer einzelnen Datei zusammengefügt (Beispiel). Bei Panoramen funktioniert es ähnlich, nur dass Sie das Panorama horizontal stitchen, anstatt es in einem Grid zu belassen (Beispiel).</p>
<p>Danach wenden Sie auf das Image-Tag lediglich noch die Methode .reel() an und fertig ist die Laube. Zusätzliche Optionen und Demos <a id="h3ix" title="schauen Sie sich bitte hier an" href="http://jquery.vostrel.cz/reel">schauen Sie sich bitte hier an</a>&#8230; <strong>Reel funktioniert</strong> übrigens <strong>auch auf dem iPhone</strong>. Um per Maus in den Ansichten scrollen zu können, wird <a id="eni8" title="jQuery.mouseWheel" href="http://github.com/brandonaaron/jquery-mousewheel/tree/master">jQuery.mouseWheel</a> benötigt.</p>
<h4>jQuery Easy Slides v1.1</h4>
<p><span class="removed_link" title="http://dev.daledavies.co.uk/easyslides/"><img class="ngg-singlepic ngg-none" src="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/easyslides.jpg" alt="easyslides.jpg" /></span></p>
<p>Ein simples, aber schickes <strong>Slideshow-System</strong> bietet jQuery Easy Slides. Es kann nicht viel mehr, als ein Bild kombiniert mit Text für eine Weile anzuzeigen und dann aufs nächste Bild überzublenden. Dafür ist es schneller implementiert als man Slideshow-System schreiben kann. Download, Demo und Doku gibt es  <span class="removed_link" title="http://dev.daledavies.co.uk/easyslides/">bei Dale Davies</span>.</p>
<h4>YoxView</h4>
<p><a href="http://www.yoxigen.com/yoxview/Default.aspx" target="_self"><img class="ngg-singlepic ngg-none" src="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/yoxview.jpg" alt="yoxview.jpg" /></a></p>
<p>Sind Sie ein Fan der Darstellung von Bildern in Overlays wie Lightbox, könnten Sie sich eventuell von <strong>YoxView</strong> begeistern lassen. YoxView ist nämlich <strong>eine Art aufgebohrtes Lightbox</strong>.</p>
<p><strong>Neben</strong> <strong>lokalen Bildern</strong> kann es <strong>auch</strong> Bilder aus <strong>Flickr</strong> und <strong>Picasa</strong> einbinden. Neben Bildern beherrscht es die Einbindung von <strong>Videos</strong> und das sogar unter <strong>Zugriff auf YouTube, Vimeo</strong> und andere.</p>
<p>YoxView ist international, ein deutsches Languagepack befindet sich im Standard-Download. Zur Demo und zum Download <a id="p.kl" title="geht es hier" href="http://www.yoxigen.com/yoxview/Default.aspx">geht es hier</a>&#8230;</p>
<h4>Horinaja</h4>
<p><img class="ngg-singlepic ngg-none" src="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/horinaja-w500.jpg" alt="horinaja-w500.jpg" /></p>
<p>Nicht notwendigerweise nur auf Bilder beschränkt, ist auch <a id="a0rv" title="Horinaja" href="http://www.davidmassiani.com/horinaja/index.php">Horinaja</a> ein <strong>Slideshow-Plugin</strong>. Neben der jQuery-Variante kann es auch unter Scriptaculous verwendet werden. Um das Mausrad verwenden zu können, wird auch hier das jQuery.mouseWheel benötigt. Da das einzublendende Element per Liste deklariert wird, können grundsätzlich auch Nichtbildinhalte mit Horinaja bewegt werden. Nur deshalb findet sich Horinaja in dieser Auflistung. Freunde der JQT finden dort unter der Bezeichnung Scrollable eine eigene Lösung vor.</p>
<p>Mit Horinaja Pro hat der Autor eine kostenpflichtige Variante nachgelegt, die einige ganz wenige Features, wie Pfeile für rechts/links scrollen hinzufügt. Da überschätzt wohl jemand die Kraft seiner Innovation&#8230;</p>
<h4>jPhotoGrid</h4>
<p><a href="http://www.gethifi.com/demos/jphotogrid" target="_self"><img class="ngg-singlepic ngg-none" src="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/jphotogrid-w500.jpg" alt="jphotogrid-w500.jpg" /></a></p>
<p>Ähnlich wie in jSquares ordnet man in <a id="cxpg" title="jPhotoGrid" href="http://www.gethifi.com/blog/jphotogrid">jPhotoGrid</a> seine <strong>Bilder in einem Raster</strong> an. Per Klick wird dann das <strong>gehoverte Bild vergrößert</strong> und per weiteren Klick an seinen Platz zurück verkleinert. Die Darstellung spielt sich innerhalb des Grid ab, so dass auf eine hinreichende Dimensionierung zu achten ist. Der <strong>Vorteil</strong> besteht auch hier darin, dass die eigentliche <strong>Website nicht</strong> von einem Overlay <strong>überlagert</strong> wird. Der <strong>Nachteil</strong> besteht darin, dass nur der Container gezoomt wird, während die <strong>Bilder in 100% Größe hinterleg</strong>t sind. Das bedeutet, der Betrachter lädt zunächst einmal alle Originalgrößen, nur um danach die ein oder andere Abbildung tatsächlich in voller Größe betrachten zu können.</p>
<p>Ein Beispiel mit ausgesprochen niedlichen Hunden <a id="og22" title="finden Sie hier" href="http://www.gethifi.com/demos/jphotogrid">finden Sie hier</a>&#8230;</p>
<h3>Plugins für die Darstellung von UI-Elementen, wie Kalender, Formulare etc.</h3>
<h4>jQuery.calendarPicker</h4>
<p><a href="http://bugsvoice.com/applications/bugsVoice/site/test/calendarPickerDemo.jsp" target="_self"><img class="ngg-singlepic ngg-none" src="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/calendarpicker-w500.png" alt="calendarpicker-w500.png" /></a></p>
<p>Anders als beim Standard-<strong>Datepicker</strong>, wie beispielsweise dem aus der jQueryUI, <strong>wählt man beim jQuery.calendarPicker die Datumsteile per Mausklick</strong> aus und lässt sie dann auch so stehen. Meiner Philosophie entspricht diese Vorgehensweise zwar nicht, ich würde stets einen klassischen Datepicker vorziehen. Ich bin auch nicht sicher, ob die Mehrzahl der Websitebesucher eine solch ungewöhnliche Implementation auf Anhieb verstehen würde. Stark visuell vorgeprägte Menschen könnten allerdings durchaus Gefallen an der schicken calendarPicker-Optik finden.</p>
<p>Interessant für den internationalen Anwender ist die Möglichkeit, <strong>nationale Konventionen</strong> zur Geltung zu bringen. Mausfanatiker werden sich über die <strong>Unterstützung des Scrollrads</strong> zur Datumswahl freuen.</p>
<p>Der Autor beschreibt sein <a id="z_dj" title="Produkt hier" href="http://roberto.open-lab.com/2010/04/06/ultra-light-jquery-calendar/">Produkt hier</a>, zur Demo geht es <a id="fueb" title="hier entlang" href="http://bugsvoice.com/applications/bugsVoice/site/test/calendarPickerDemo.jsp">hier entlang</a>&#8230;</p>
<h4>Any+Time</h4>
<p><a href="http://www.ama3.com/anytime/" target="_self"><img class="ngg-singlepic ngg-none" src="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/anytime-w500.png" alt="anytime-w500.png" /></a></p>
<p><a id="uzm4" title="Any+Time" href="http://www.ama3.com/anytime/">Any+Time</a> ist der Mercedes, ach was, der <strong>Rolls Royce unter den Datepicker-Plugins</strong>. Any+Time denkt das Konzept der Bedienerfreundlichkeit für den Aufgabenbereich der Zeit- und Datumsauswahl und -weiterverarbeitung zu Ende. Dabei ist er international einsetzbar und lässt sich auch im Zusammenspiel mit Datenbanken und deren erwünschten Formatkonventionen verwenden. Ein <strong>vollkommen flexibles Theming</strong>, unter anderem kann der jQuery UI Themeroller eingesetzt werden, sorgt für optische Anpassbarkeit ohne Einschränkungen.</p>
<p><strong>Pluspunkt</strong>: Auch Nutzer ohne Maus können Any+Time dank <strong>WIA-ARIA-Konformität</strong> bedienen.</p>
<h4>jDigiClock</h4>
<p><a href="http://www.radoslavdimov.com/jquery-plugins/jquery-plugin-digiclock/" target="_self"><img class="ngg-singlepic ngg-none" src="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/jdigiclock.jpg" alt="jdigiclock.jpg" /></a></p>
<p>Das Plugin <a id="ppb7" title="jDigiClock" href="http://www.radoslavdimov.com/jquery-plugins/jquery-plugin-digiclock/">jDigiClock</a> leistet nicht mehr und nicht weniger als die Darstellung einer schicken <strong>Retro-Uhr</strong> unter gleichzeitiger grafischer <strong>Darstellung des örtlichen Wetters</strong>.</p>
<h4>jQuery.CharCount</h4>
<p><a href="http://cssglobe.com/lab/charcount/01.html" target="_self"><img class="ngg-singlepic ngg-none" src="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/charcount-w500.jpg" alt="charcount-w500.jpg" /></a></p>
<p>Ist dieses <a id="b8q4" title="Plugin" href="http://cssglobe.com/post/7161/jquery-plugin-simplest-twitterlike-dynamic-character-count-for-textareas">Plugin</a> in einem <strong>Formularfeld</strong> aktiv, zählt es die eingetippten Zeichen herunter und ist dabei in der Lage, <strong>vor Erreichen der Zeichenhöchstgrenze zu warnen</strong>. Vorbild war offenbar Twitter. Aber auch auf der Website Ihres Kunden mag es Eingabefelder geben, die zum Beispiel wegen Konventionen der dahinter liegenden Datenbank auf eine maximale Zeichenzahl begrenzt werden müssen. Eine Demo finden Sie <a id="s9-3" title="hier" href="http://cssglobe.com/lab/charcount/01.html">hier</a>&#8230;</p>
<h4>Quicksand</h4>
<p><a href="http://razorjack.net/quicksand/" target="_self"><img class="ngg-singlepic ngg-none" src="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/quicksand.jpg" alt="quicksand.jpg" /></a></p>
<p><a id="wk53" title="Quicksand" href="http://razorjack.net/quicksand/docs-and-demos.html">Quicksand</a> ist eine Hommage an das Bedienkonzept des Mac. Es ermöglicht UI-Entwicklern gegebene <strong>Iconsets nach unterschiedlichen Kriterien</strong> zu <strong>sortieren</strong> und dabei ein- oder auszublenden. Schauen Sie sich <a id="o-n9" title="die elegante Demo" href="http://razorjack.net/quicksand/">die elegante Demo</a> dazu an.</p>
<p>Quicksand ist in seiner kleinen Nische sicher eine <strong>Bereicherung für stark visuell orientierte Websites</strong> mit einer hohen Zahl von Icons und Bedienmöglichkeiten.</p>
<h4>Jeegoocontext</h4>
<p><img class="ngg-singlepic ngg-none" src="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/jeegocontext-w500.png" alt="jeegocontext-w500.png" /></p>
<p><a id="z_-2" title="Jeegoocontext" href="http://www.planitworks.nl/jeegoocontext/">Jeegoocontext</a> erlaubt das <strong>Erstellen komfortabler Kontextmenüs</strong> mit voller Gestaltungsfreiheit <strong>via CSS</strong>. Es können beliebig viele unterschiedliche Kontextmenüs auf der gleichen Seite existieren. Die Menüs können sehr komplex werden, wie diese Demo anschaulich zeigt.</p>
<p>Jeegoocontext ist nicht für jede Website nützlich, kann jedoch auf sehr komplexen Projekten entscheidend zur Bedienbarkeit beitragen.</p>
<h4>Ketchup</h4>
<p><img class="ngg-singlepic ngg-none" src="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/ketchup-w500.png" alt="ketchup-w500.png" /></p>
<p>Ketchup ist ein jQuery-Plugin zur <strong>Formularvalidierung</strong>. Wenn Sie glauben, für einen solchen simplen Task sei ein jQuery-Plugin nun wirklich nicht erforderlich, könnten Sie sich irren. Ketchups Validierung sieht nicht nur besser aus als jedes Standardjavascript, es ist auch mindestens genau so <strong>schnell implementiert</strong>. Bereits im Auslieferungszustand kann sich die Optik sehen lassen. Selbstverständlich sind Sie in der <strong>Gestaltung völlig frei</strong>.</p>
<h4>Chroma-Hash</h4>
<p><img class="ngg-singlepic ngg-none" src="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/chromahash.png" alt="chromahash.png" /></p>
<p><a id="v6sy" title="Chroma-Hash" href="http://mattt.github.com/Chroma-Hash/">Chroma-Hash</a> ist ein jQuery-Plugin, welches Formularfelder zur Passworteingabe um einen Farbcode erweitert. Muss man zwei Mal das gleiche Passwort eingeben, kann man bereits am Farbcode erkennen, ob man sich verschrieben hat. Die Nützlichkeit des Plugins ist äußerst umstritten. Machen Sie sich selbst ein Bild.</p>
<h4>Feature List</h4>
<p><a href="http://jqueryglobe.com/labs/feature_list/" target="_self"><img class="ngg-singlepic ngg-none" src="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/featurelist-w500.png" alt="featurelist-w500.png" /></a></p>
<p><a id="wmtu" title="Feature List" href="http://jqueryglobe.com/article/feature-list">Feature List</a> verwandelt schlichte ULs in <a id="q_1g" title="schicke Rotationsoberflächen" href="http://jqueryglobe.com/labs/feature_list/">schicke Rotationsoberflächen</a>. Das ist ideal, wenn man als Dienstleister seine Kernkompetenzen schlagkräftig auf der Startseite präsentieren will. Das Plugin verfügt über etliche Einstellungsmöglichkeiten, etwa ob automatisch, beim Hovern oder erst bei Mausklick rotiert werden soll und ist mit 2kb wirklich klein.</p>
<h4>Meerkat</h4>
<p><img class="ngg-singlepic ngg-none" src="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/meerkat-w500.png" alt="meerkat-w500.png" /></p>
<p>Mit Hilfe von <a id="rgoa" title="Meerkat" href="http://meerkat.jarodtaylor.com/">Meerkat</a> erstellen Sie <strong>nicht verschiebbare Bereiche</strong>, die oben, unten, links oder rechts auf Ihrer Website angezeigt werden Das kann für penetrante <strong>Werbung</strong> (<a id="d3mg" title="wie im Beispiel" href="http://meerkat.jarodtaylor.com/demo/basic-usage/#">wie im Beispiel</a>), aber auch für <strong>Navigationselemente</strong> nützlich sein. Es besteht die Möglichkeit, die <strong>Bereiche per Klick schließbar</strong> zu <strong>machen</strong> und per Cookie auf dem gleichen Computer dann auch nicht mehr anzuzeigen (was natürlich nur für penetrante Werbung Sinn macht&#8230;).</p>
<h4>tinyTips</h4>
<p><span class="removed_link" title="http://www.digitalinferno.net/demos/tt-1-0/index.html"><img class="ngg-singlepic ngg-none" src="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/tinytips.jpg" alt="tinytips.jpg" /></span></p>
<p>Mit <span class="removed_link" title="http://www.digitalinferno.net/blog/jquery-plugin-tinytips-1-0/">tinyTips</span> erstellen Sie an nahezu jedem Element <strong>Tooltips</strong>. Neben kurzen, sind <strong>auch längere Texte</strong>, wie das <strong>Einbinden von Bildern</strong> in die Tooltips möglich. <span class="removed_link" title="http://www.digitalinferno.net/demos/tt-1-0/index.html">Die Demo</span> zeugt von der Eleganz dieser leichtgewichtigen und einfach verwendbaren Lösung.</p>
<h4>Spritely</h4>
<p><a href="http://www.spritely.net/documentation/" target="_self"><img class="ngg-singlepic ngg-none" src="https://www.drweb.de/magazin/wp-content/gallery/jquery-tools-plugins-20100504/spritely.jpg" alt="spritely.jpg" /></a></p>
<p>Zu guter Letzt sei noch das Plugin <a id="a1wf" title="Spritely" href="http://www.spritely.net/">Spritely</a> erwähnt. <strong>Spritely animiert Objekte vor einem Hintergrund und den Hintergrund selbst</strong>. Der Hintergrund besteht dabei aus einem Panorama, das nahtlos abgespielt wird, während die Vordergrundobjekte aus <strong>Sprites</strong> bestehen, die als PNG-Datei mit ihren jeweiligen Zuständen abgespeichert werden.</p>
<p>Der auf <a id="s3vu" title="der Spritely-Site verwendete Vogel" href="http://www.spritely.net/documentation/">der Spritely-Site verwendete Vogel</a> beispielsweise wird aus einer PNG mit drei Flugzuständen des Vogels, also 3 Frames animiert. Für komplexere Animationen ist auch eine höhere Zahl von Frames möglich. Die Zahl übergibt man der Funktion zusammen mit dem Wert für Frames per second (fps) und steuert so die Animation hinsichtlich Komplexität und Geschwindigkeit.</p>
<p>Der Hersteller spricht von Spritely als <strong>Flash-Ersatz</strong>. Das ist sicherlich zu hoch gegriffen. Dennoch kann Spritely in vielen Fällen bessere Dienste leisten, als die vielfach unnötig in Flash umgesetzten Billiganimationen, die derzeit noch das Web bevölkern. <strong>Spritely funktioniert auf iPhone und iPad</strong>.</p>
<p><em>(mm),</em></p>
							</div>
							</div><!-- /.zilla-two-third-->
							<div class="zilla-one-third zilla-column-last" id="artikel-sidebar">
                             </div>
                             <div class="clear"></div>
                             <div class="ad-widget-bottom">			<div class="textwidget"><div id="medium_rectangle_artikelseite_unten" data-ad-zone-id="115"></div></div>
		</div>   
                            							<div class="mashshare-bottom">
							<div class="total-shares"><i class="fa fa-share-alt"></i><span class="shariff" data-services="totalnumber" data-url="https%3A%2F%2Fwww.drweb.de%2Fmagazin%2Fjquery-die-interessantesten-aktuellen-plugins-und-tools%2F"><span class="shariff-totalnumber">0</span></span></div>
                             <div class="share-buttons"><div class="shariff shariff-main shariff-align-flex-start shariff-widget-align-flex-start shariff-buttonstretch" style="display:none" data-services="facebook%7Ctwitter%7Cgoogleplus%7Cxing" data-url="https%3A%2F%2Fwww.drweb.de%2Fmagazin%2Fjquery-die-interessantesten-aktuellen-plugins-und-tools%2F" data-timestamp="1462791788" data-hidezero="1" data-backendurl="https://www.drweb.de/magazin/wp-json/shariff/v1/share_counts?"><ul class="shariff-buttons theme-color orientation-horizontal buttonsize-medium"><li class="shariff-button facebook" style="background-color:#4273c8"><a href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fwww.drweb.de%2Fmagazin%2Fjquery-die-interessantesten-aktuellen-plugins-und-tools%2F" title="Bei Facebook teilen" aria-label="Bei Facebook teilen" role="button" rel="noopener nofollow" class="shariff-link" target="_blank" style="background-color:#3b5998; color:#fff"><span class="shariff-icon"><svg width="32px" height="20px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 32"><path d="M17.1 0.2v4.7h-2.8q-1.5 0-2.1 0.6t-0.5 1.9v3.4h5.2l-0.7 5.3h-4.5v13.6h-5.5v-13.6h-4.5v-5.3h4.5v-3.9q0-3.3 1.9-5.2t5-1.8q2.6 0 4.1 0.2z"/></svg></span><span class="shariff-text">teilen</span>&nbsp;<span class="shariff-count" data-service="facebook" style="color:#3b5998;opacity:0"></span>&nbsp;</a></li><li class="shariff-button twitter" style="background-color:#32bbf5"><a href="https://twitter.com/share?url=https%3A%2F%2Fwww.drweb.de%2Fmagazin%2Fjquery-die-interessantesten-aktuellen-plugins-und-tools%2F&text=jQuery+%E2%80%93+die+interessantesten+aktuellen+Plugins+und+Tools&via=drwebmagazin" title="Bei Twitter teilen" aria-label="Bei Twitter teilen" role="button" rel="noopener nofollow" class="shariff-link" target="_blank" style="background-color:#55acee; color:#fff"><span class="shariff-icon"><svg width="32px" height="20px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 32"><path d="M29.7 6.8q-1.2 1.8-3 3.1 0 0.3 0 0.8 0 2.5-0.7 4.9t-2.2 4.7-3.5 4-4.9 2.8-6.1 1q-5.1 0-9.3-2.7 0.6 0.1 1.5 0.1 4.3 0 7.6-2.6-2-0.1-3.5-1.2t-2.2-3q0.6 0.1 1.1 0.1 0.8 0 1.6-0.2-2.1-0.4-3.5-2.1t-1.4-3.9v-0.1q1.3 0.7 2.8 0.8-1.2-0.8-2-2.2t-0.7-2.9q0-1.7 0.8-3.1 2.3 2.8 5.5 4.5t7 1.9q-0.2-0.7-0.2-1.4 0-2.5 1.8-4.3t4.3-1.8q2.7 0 4.5 1.9 2.1-0.4 3.9-1.5-0.7 2.2-2.7 3.4 1.8-0.2 3.5-0.9z"/></svg></span><span class="shariff-text">twittern</span>&nbsp;<span class="shariff-count" data-service="twitter" style="color:#55acee;opacity:0"></span>&nbsp;</a></li><li class="shariff-button googleplus" style="background-color:#f75b44"><a href="https://plus.google.com/share?url=https%3A%2F%2Fwww.drweb.de%2Fmagazin%2Fjquery-die-interessantesten-aktuellen-plugins-und-tools%2F" title="Bei Google+ teilen" aria-label="Bei Google+ teilen" role="button" rel="noopener nofollow" class="shariff-link" target="_blank" style="background-color:#d34836; color:#fff"><span class="shariff-icon"><svg width="32px" height="20px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><path d="M31.6 14.7h-3.3v-3.3h-2.6v3.3h-3.3v2.6h3.3v3.3h2.6v-3.3h3.3zM10.8 14v4.1h5.7c-0.4 2.4-2.6 4.2-5.7 4.2-3.4 0-6.2-2.9-6.2-6.3s2.8-6.3 6.2-6.3c1.5 0 2.9 0.5 4 1.6v0l2.9-2.9c-1.8-1.7-4.2-2.7-7-2.7-5.8 0-10.4 4.7-10.4 10.4s4.7 10.4 10.4 10.4c6 0 10-4.2 10-10.2 0-0.8-0.1-1.5-0.2-2.2 0 0-9.8 0-9.8 0z"/></svg></span><span class="shariff-text">teilen</span>&nbsp;<span class="shariff-count" data-service="googleplus" style="color:#d34836;opacity:0"></span>&nbsp;</a></li><li class="shariff-button xing" style="background-color:#29888a"><a href="https://www.xing.com/social_plugins/share?url=https%3A%2F%2Fwww.drweb.de%2Fmagazin%2Fjquery-die-interessantesten-aktuellen-plugins-und-tools%2F" title="Bei Xing teilen" aria-label="Bei Xing teilen" role="button" rel="noopener nofollow" class="shariff-link" target="_blank" style="background-color:#126567; color:#fff"><span class="shariff-icon"><svg width="32px" height="20px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 25 32"><path d="M10.7 11.9q-0.2 0.3-4.6 8.2-0.5 0.8-1.2 0.8h-4.3q-0.4 0-0.5-0.3t0-0.6l4.5-8q0 0 0 0l-2.9-5q-0.2-0.4 0-0.7 0.2-0.3 0.5-0.3h4.3q0.7 0 1.2 0.8zM25.1 0.4q0.2 0.3 0 0.7l-9.4 16.7 6 11q0.2 0.4 0 0.6-0.2 0.3-0.6 0.3h-4.3q-0.7 0-1.2-0.8l-6-11.1q0.3-0.6 9.5-16.8 0.4-0.8 1.2-0.8h4.3q0.4 0 0.5 0.3z"/></svg></span><span class="shariff-text">teilen</span>&nbsp;<span class="shariff-count" data-service="xing" style="color:#126567;opacity:0"></span>&nbsp;</a></li><li class="shariff-button mailform" style="background-color:#a8a8a8"><a href="https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/?view=mail#shariff_mailform" title="Per E-Mail versenden" aria-label="Per E-Mail versenden" role="button" rel="noopener nofollow" class="shariff-link" style="background-color:#999; color:#fff"><span class="shariff-icon"><svg width="32px" height="20px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><path d="M32 12.7v14.2q0 1.2-0.8 2t-2 0.9h-26.3q-1.2 0-2-0.9t-0.8-2v-14.2q0.8 0.9 1.8 1.6 6.5 4.4 8.9 6.1 1 0.8 1.6 1.2t1.7 0.9 2 0.4h0.1q0.9 0 2-0.4t1.7-0.9 1.6-1.2q3-2.2 8.9-6.1 1-0.7 1.8-1.6zM32 7.4q0 1.4-0.9 2.7t-2.2 2.2q-6.7 4.7-8.4 5.8-0.2 0.1-0.7 0.5t-1 0.7-0.9 0.6-1.1 0.5-0.9 0.2h-0.1q-0.4 0-0.9-0.2t-1.1-0.5-0.9-0.6-1-0.7-0.7-0.5q-1.6-1.1-4.7-3.2t-3.6-2.6q-1.1-0.7-2.1-2t-1-2.5q0-1.4 0.7-2.3t2.1-0.9h26.3q1.2 0 2 0.8t0.9 2z"/></svg></span><span class="shariff-text">E-Mail</span>&nbsp;</a></li></ul></div></div>
                             <div class="clear"></div>
                            </div>
                            <div class="author-bio">
<div class="bio-avatar"><img alt='' src='https://secure.gravatar.com/avatar/2d124df6c46d7b60abba7f1e809ee6e2?s=128&#038;d=identicon&#038;r=pg' srcset='https://secure.gravatar.com/avatar/2d124df6c46d7b60abba7f1e809ee6e2?s=256&amp;d=identicon&amp;r=pg 2x' class='avatar avatar-128 photo' height='128' width='128' /></div>
<div class="author-inner">
<p class="bio-name"><a class="author-name" href="https://www.drweb.de/magazin/author/dieter-petereit/">Dieter Petereit</a></p>
<p class="bio-desc">ist seit 1994 im Netz unterwegs, aber bereits seit über 30 Jahren in der IT daheim. Seit Anfang des neuen Jahrtausends schreibt er für diverse Medien, hauptsächlich zu den Themenfeldern Technik und Design. Man findet ihn auch auf <a href="https://twitter.com/#!/dpetereit">Twitter</a> und <a href="https://plus.google.com/u/0/101026873872956334466?rel=author">Google+</a>.</p>
<div class="simple-social-icons">
<ul class="social-link clearfix">
       <!-- facebook -->
        <li><a href="http://www.dpetereit.com/" title="Authors Website" target="_blank"><i class="fa fa-link" aria-hidden="true"></i></a></li>
        <!-- facebook -->
    
    <!-- twitter -->
    
    <!-- feed -->
    
    <!-- google plus -->
    
    <!-- linkedin -->
            <!-- flickr -->
            <!-- flickr -->
    </ul>
</div>
</div>
<!-- social-link -->
<div class="clear"></div>
</div>   
                            <div class="matched-posts">    
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<ins class="adsbygoogle"
     style="display:block"
     data-ad-format="autorelaxed"
     data-ad-client="ca-pub-1081357423874758"
     data-ad-slot="9081342000"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>
							<nav class="pagination group">
                              </nav><!--/.pagination-->
						
            
            
            

            
						<div class="clear"></div>
					</div><!--/.entry implode-->

				</div><!--/.post-inner-->
			</article><!--/.post-->
		
		<div class="clear"></div>
        <div class="post-title-main-inner">
				

		
		
				    <div class="wpdiscuz_top_clearing"></div>
                                <div id="comments" class="comments-area">
                    <div id="respond" style="width: 0;height: 0;clear: both;margin: 0;padding: 0;"></div>
                                                    <div id="wpcomm" class="wpdiscuz_unauth" style="border:none;">
                                
                                    <div class="wpdiscuz-front-actions">
                        <div class="wpdiscuz-sort-buttons" style="font-size:14px;">Sortiert nach: &nbsp;
                            <span class="wpdiscuz-sort-button wpdiscuz-date-sort-desc">neueste</span> | 
                            <span class="wpdiscuz-sort-button wpdiscuz-date-sort-asc">älteste</span>
                                                            | <span class="wpdiscuz-sort-button wpdiscuz-vote-sort-up">beste Bewertung</span>
                                                    </div>
                    </div>
                
                                <div id="wcThreadWrapper" class="wc-thread-wrapper">
                    <div id="wc-comm-37144_0" class="wc-comment wc-blog-guest wc_comment_level-1"><div class="wc-comment-left "><img alt='Markus Bauer' src='https://secure.gravatar.com/avatar/43af16227b5bd70a9fb9eaf8f3998bf5?s=64&#038;d=identicon&#038;r=pg' srcset='https://secure.gravatar.com/avatar/43af16227b5bd70a9fb9eaf8f3998bf5?s=128&amp;d=identicon&amp;r=pg 2x' class='avatar avatar-64 photo' height='64' width='64' /><div class="wc-blog-guest wc-comment-label"><span>Gast</span></div></div><div id="comment-37144" class="wc-comment-right " ><div class="wc-comment-header"><div class="wc-comment-author "><a rel='nofollow' href='http://s1-suchmaschinenoptimierung.de/' target='_blank'>Markus Bauer</a></div><div class="wc-comment-link"><i class="fa fa-share-alt wc-share-link wpf-cta" aria-hidden="true" title="teilen" ></i><span class="share_buttons_box"><a class="wc_tw" target="_blank" href="https://twitter.com/home?status=" title=""><i class="fa fa-twitter wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a><a class="wc_go" target="_blank" href="https://plus.google.com/share?url=https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/" title=""><i class="fa fa-google wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a></span><span class="wc-comment-img-link-wrap"><i class="fa fa-link wc-comment-img-link wpf-cta" aria-hidden="true"/></i><span><input type="text" class="wc-comment-link-input" value="https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/#comment-37144" /></span></span></div><div class="wpdiscuz_clear"></div></div><div class="wc-comment-text"><p>Dass jQuery immer populärer wird, sieht man an der aktuell stark zunehmenden Zahl von Publikationen zu / über jQuery &#8211; aber das ist beste Artikel, den ich bisher gelesen habe: kenntnisreich, leicht lesbar und schnell einen guten Überblick vermittelnd. Danke dafür.</p>
</div><div class="wc-comment-footer"><div class="wc-footer-left"><span class="wc-vote-link wc-up  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-up fa-flip-horizontal wc-vote-img-up"></i><span>Daumen hoch</span></span><span class="wc-vote-result">0</span><span class="wc-vote-link wc-down  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-down wc-vote-img-down"></i><span>Daumen runter</span></span>&nbsp;</div><div class="wc-footer-right"><div class="wc-comment-date"><i class="fa fa-clock-o" aria-hidden="true"></i>7 Jahre 1 Monat her</div><div class="wc-toggle wpdiscuz-hidden"><i class="fa fa-chevron-up" aria-hidden="true"  title="Antworten verbergen"></i></div></div><div class="wpdiscuz_clear"></div></div></div><div class="wpdiscuz-comment-message"></div><div id="wpdiscuz_form_anchor-37144_0"  style="clear:both"></div></div><div id="wc-comm-37145_0" class="wc-comment wc-blog-guest wc_comment_level-1"><div class="wc-comment-left "><img alt='rené' src='https://secure.gravatar.com/avatar/4b7ab249866c84b757963f56f981fa39?s=64&#038;d=identicon&#038;r=pg' srcset='https://secure.gravatar.com/avatar/4b7ab249866c84b757963f56f981fa39?s=128&amp;d=identicon&amp;r=pg 2x' class='avatar avatar-64 photo' height='64' width='64' /><div class="wc-blog-guest wc-comment-label"><span>Gast</span></div></div><div id="comment-37145" class="wc-comment-right " ><div class="wc-comment-header"><div class="wc-comment-author ">rené</div><div class="wc-comment-link"><i class="fa fa-share-alt wc-share-link wpf-cta" aria-hidden="true" title="teilen" ></i><span class="share_buttons_box"><a class="wc_tw" target="_blank" href="https://twitter.com/home?status=" title=""><i class="fa fa-twitter wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a><a class="wc_go" target="_blank" href="https://plus.google.com/share?url=https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/" title=""><i class="fa fa-google wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a></span><span class="wc-comment-img-link-wrap"><i class="fa fa-link wc-comment-img-link wpf-cta" aria-hidden="true"/></i><span><input type="text" class="wc-comment-link-input" value="https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/#comment-37145" /></span></span></div><div class="wpdiscuz_clear"></div></div><div class="wc-comment-text"><p>Super Sammlung.<br />
Übrigens finde ich die Aussage zu Spritely als Flash-Ersatz in Bezug auf animierte Elemente einer Website, nicht als zu hoch gegriffen.</p>
</div><div class="wc-comment-footer"><div class="wc-footer-left"><span class="wc-vote-link wc-up  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-up fa-flip-horizontal wc-vote-img-up"></i><span>Daumen hoch</span></span><span class="wc-vote-result">0</span><span class="wc-vote-link wc-down  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-down wc-vote-img-down"></i><span>Daumen runter</span></span>&nbsp;</div><div class="wc-footer-right"><div class="wc-comment-date"><i class="fa fa-clock-o" aria-hidden="true"></i>7 Jahre 1 Monat her</div><div class="wc-toggle wpdiscuz-hidden"><i class="fa fa-chevron-up" aria-hidden="true"  title="Antworten verbergen"></i></div></div><div class="wpdiscuz_clear"></div></div></div><div class="wpdiscuz-comment-message"></div><div id="wpdiscuz_form_anchor-37145_0"  style="clear:both"></div></div><div id="wc-comm-37147_0" class="wc-comment wc-blog-guest wc_comment_level-1"><div class="wc-comment-left "><img alt='Dominik Hahn' src='https://secure.gravatar.com/avatar/be0841141487d22c4aef7820a220e614?s=64&#038;d=identicon&#038;r=pg' srcset='https://secure.gravatar.com/avatar/be0841141487d22c4aef7820a220e614?s=128&amp;d=identicon&amp;r=pg 2x' class='avatar avatar-64 photo' height='64' width='64' /><div class="wc-blog-guest wc-comment-label"><span>Gast</span></div></div><div id="comment-37147" class="wc-comment-right " ><div class="wc-comment-header"><div class="wc-comment-author "><a rel='nofollow' href='http://dominikhahn.com' target='_blank'>Dominik Hahn</a></div><div class="wc-comment-link"><i class="fa fa-share-alt wc-share-link wpf-cta" aria-hidden="true" title="teilen" ></i><span class="share_buttons_box"><a class="wc_tw" target="_blank" href="https://twitter.com/home?status=" title=""><i class="fa fa-twitter wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a><a class="wc_go" target="_blank" href="https://plus.google.com/share?url=https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/" title=""><i class="fa fa-google wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a></span><span class="wc-comment-img-link-wrap"><i class="fa fa-link wc-comment-img-link wpf-cta" aria-hidden="true"/></i><span><input type="text" class="wc-comment-link-input" value="https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/#comment-37147" /></span></span></div><div class="wpdiscuz_clear"></div></div><div class="wc-comment-text"><p>Der Link zu jQuery Tools ist falsch, da ist ein &#8216;l&#8217; zuviel  hinterm &#8216;html&#8217;.</p>
</div><div class="wc-comment-footer"><div class="wc-footer-left"><span class="wc-vote-link wc-up  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-up fa-flip-horizontal wc-vote-img-up"></i><span>Daumen hoch</span></span><span class="wc-vote-result">0</span><span class="wc-vote-link wc-down  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-down wc-vote-img-down"></i><span>Daumen runter</span></span>&nbsp;</div><div class="wc-footer-right"><div class="wc-comment-date"><i class="fa fa-clock-o" aria-hidden="true"></i>7 Jahre 1 Monat her</div><div class="wc-toggle wpdiscuz-hidden"><i class="fa fa-chevron-up" aria-hidden="true"  title="Antworten verbergen"></i></div></div><div class="wpdiscuz_clear"></div></div></div><div class="wpdiscuz-comment-message"></div><div id="wpdiscuz_form_anchor-37147_0"  style="clear:both"></div></div><div id="wc-comm-37148_0" class="wc-comment wc-blog-guest wc_comment_level-1"><div class="wc-comment-left "><img alt='c0de' src='https://secure.gravatar.com/avatar/459479f7e15a55f4adeecf210ea6545a?s=64&#038;d=identicon&#038;r=pg' srcset='https://secure.gravatar.com/avatar/459479f7e15a55f4adeecf210ea6545a?s=128&amp;d=identicon&amp;r=pg 2x' class='avatar avatar-64 photo' height='64' width='64' /><div class="wc-blog-guest wc-comment-label"><span>Gast</span></div></div><div id="comment-37148" class="wc-comment-right " ><div class="wc-comment-header"><div class="wc-comment-author "><a rel='nofollow' href='http://c0de.at' target='_blank'>c0de</a></div><div class="wc-comment-link"><i class="fa fa-share-alt wc-share-link wpf-cta" aria-hidden="true" title="teilen" ></i><span class="share_buttons_box"><a class="wc_tw" target="_blank" href="https://twitter.com/home?status=" title=""><i class="fa fa-twitter wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a><a class="wc_go" target="_blank" href="https://plus.google.com/share?url=https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/" title=""><i class="fa fa-google wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a></span><span class="wc-comment-img-link-wrap"><i class="fa fa-link wc-comment-img-link wpf-cta" aria-hidden="true"/></i><span><input type="text" class="wc-comment-link-input" value="https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/#comment-37148" /></span></span></div><div class="wpdiscuz_clear"></div></div><div class="wc-comment-text"><p>Klar jeder braucht umbedingt jQuery image Galerien&#8230;. Wie wenn es da nicht schon genug gäbe&#8230; nja&#8230; aber ein paar schöne sachen habt ihr da entdeckt!</p>
</div><div class="wc-comment-footer"><div class="wc-footer-left"><span class="wc-vote-link wc-up  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-up fa-flip-horizontal wc-vote-img-up"></i><span>Daumen hoch</span></span><span class="wc-vote-result">0</span><span class="wc-vote-link wc-down  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-down wc-vote-img-down"></i><span>Daumen runter</span></span>&nbsp;</div><div class="wc-footer-right"><div class="wc-comment-date"><i class="fa fa-clock-o" aria-hidden="true"></i>7 Jahre 1 Monat her</div><div class="wc-toggle wpdiscuz-hidden"><i class="fa fa-chevron-up" aria-hidden="true"  title="Antworten verbergen"></i></div></div><div class="wpdiscuz_clear"></div></div></div><div class="wpdiscuz-comment-message"></div><div id="wpdiscuz_form_anchor-37148_0"  style="clear:both"></div></div><div id="wc-comm-37150_0" class="wc-comment wc-blog-guest wc_comment_level-1"><div class="wc-comment-left "><img alt='Dieter Petereit' src='https://secure.gravatar.com/avatar/0161d2f47b27e48dab45a0f0c17541f3?s=64&#038;d=identicon&#038;r=pg' srcset='https://secure.gravatar.com/avatar/0161d2f47b27e48dab45a0f0c17541f3?s=128&amp;d=identicon&amp;r=pg 2x' class='avatar avatar-64 photo' height='64' width='64' /><div class="wc-blog-guest wc-comment-label"><span>Gast</span></div></div><div id="comment-37150" class="wc-comment-right " ><div class="wc-comment-header"><div class="wc-comment-author "><a rel='nofollow' href='http://www.blogmanufaktur.de' target='_blank'>Dieter Petereit</a></div><div class="wc-comment-link"><i class="fa fa-share-alt wc-share-link wpf-cta" aria-hidden="true" title="teilen" ></i><span class="share_buttons_box"><a class="wc_tw" target="_blank" href="https://twitter.com/home?status=" title=""><i class="fa fa-twitter wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a><a class="wc_go" target="_blank" href="https://plus.google.com/share?url=https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/" title=""><i class="fa fa-google wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a></span><span class="wc-comment-img-link-wrap"><i class="fa fa-link wc-comment-img-link wpf-cta" aria-hidden="true"/></i><span><input type="text" class="wc-comment-link-input" value="https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/#comment-37150" /></span></span></div><div class="wpdiscuz_clear"></div></div><div class="wc-comment-text"><p>@Dominik Hahn: Danke für den Hinweis. Link ist korrigiert.</p>
</div><div class="wc-comment-footer"><div class="wc-footer-left"><span class="wc-vote-link wc-up  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-up fa-flip-horizontal wc-vote-img-up"></i><span>Daumen hoch</span></span><span class="wc-vote-result">0</span><span class="wc-vote-link wc-down  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-down wc-vote-img-down"></i><span>Daumen runter</span></span>&nbsp;</div><div class="wc-footer-right"><div class="wc-comment-date"><i class="fa fa-clock-o" aria-hidden="true"></i>7 Jahre 1 Monat her</div><div class="wc-toggle wpdiscuz-hidden"><i class="fa fa-chevron-up" aria-hidden="true"  title="Antworten verbergen"></i></div></div><div class="wpdiscuz_clear"></div></div></div><div class="wpdiscuz-comment-message"></div><div id="wpdiscuz_form_anchor-37150_0"  style="clear:both"></div></div><div id="wc-comm-37162_0" class="wc-comment wc-blog-guest wc_comment_level-1"><div class="wc-comment-left "><img class="avatar avatar-64 photo" width="64" height="64" src="https://www.drweb.de/magazin/wp-content/plugins/wpdiscuz/assets/img/trackback.png" alt="trackback"></div><div id="comment-37162" class="wc-comment-right " ><div class="wc-comment-header"><div class="wc-comment-author "><a rel='nofollow' href='http://www.webdesignzone.de/2010/05/07/interessantes-vom-2010-05-07/' target='_blank'>Interessantes vom 2010-05-07 | WebdesignZone</a></div><div class="wc-comment-link"><i class="fa fa-share-alt wc-share-link wpf-cta" aria-hidden="true" title="teilen" ></i><span class="share_buttons_box"><a class="wc_tw" target="_blank" href="https://twitter.com/home?status=" title=""><i class="fa fa-twitter wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a><a class="wc_go" target="_blank" href="https://plus.google.com/share?url=https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/" title=""><i class="fa fa-google wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a></span><span class="wc-comment-img-link-wrap"><i class="fa fa-link wc-comment-img-link wpf-cta" aria-hidden="true"/></i><span><input type="text" class="wc-comment-link-input" value="https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/#comment-37162" /></span></span></div><div class="wpdiscuz_clear"></div></div><div class="wc-comment-text"><p>[&#8230;] Design &#8211; 50 Free High Quality Icons <a href="http://goo.gl/Vy5c" rel="nofollow">http://goo.gl/Vy5c</a> #RT: @wowawebdesign: Gute Übersicht. <a href="http://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/" rel="nofollow">http://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/</a> #jquery #RT: @opera: Check out Icon Creator, a great tool to make professional looking Widgets [&#8230;]</p>
</div><div class="wc-comment-footer"><div class="wc-footer-left"><span class="wc-vote-link wc-up  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-up fa-flip-horizontal wc-vote-img-up"></i><span>Daumen hoch</span></span><span class="wc-vote-result">0</span><span class="wc-vote-link wc-down  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-down wc-vote-img-down"></i><span>Daumen runter</span></span>&nbsp;</div><div class="wc-footer-right"><div class="wc-comment-date"><i class="fa fa-clock-o" aria-hidden="true"></i>7 Jahre 1 Monat her</div><div class="wc-toggle wpdiscuz-hidden"><i class="fa fa-chevron-up" aria-hidden="true"  title="Antworten verbergen"></i></div></div><div class="wpdiscuz_clear"></div></div></div><div class="wpdiscuz-comment-message"></div><div id="wpdiscuz_form_anchor-37162_0"  style="clear:both"></div></div><div id="wc-comm-37166_0" class="wc-comment wc-blog-guest wc_comment_level-1"><div class="wc-comment-left "><img alt='MBDealer' src='https://secure.gravatar.com/avatar/68ccad159b81ab8b590b22975549d6a3?s=64&#038;d=identicon&#038;r=pg' srcset='https://secure.gravatar.com/avatar/68ccad159b81ab8b590b22975549d6a3?s=128&amp;d=identicon&amp;r=pg 2x' class='avatar avatar-64 photo' height='64' width='64' /><div class="wc-blog-guest wc-comment-label"><span>Gast</span></div></div><div id="comment-37166" class="wc-comment-right " ><div class="wc-comment-header"><div class="wc-comment-author "><a rel='nofollow' href='http://www.mbdealer.de/' target='_blank'>MBDealer</a></div><div class="wc-comment-link"><i class="fa fa-share-alt wc-share-link wpf-cta" aria-hidden="true" title="teilen" ></i><span class="share_buttons_box"><a class="wc_tw" target="_blank" href="https://twitter.com/home?status=" title=""><i class="fa fa-twitter wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a><a class="wc_go" target="_blank" href="https://plus.google.com/share?url=https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/" title=""><i class="fa fa-google wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a></span><span class="wc-comment-img-link-wrap"><i class="fa fa-link wc-comment-img-link wpf-cta" aria-hidden="true"/></i><span><input type="text" class="wc-comment-link-input" value="https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/#comment-37166" /></span></span></div><div class="wpdiscuz_clear"></div></div><div class="wc-comment-text"><p>Der JQueryPad Editor ist echt genial so etwas suche ich schon seit langem. Minimalistisches Tool aber durchaus sehr nützlich. Danke!</p>
</div><div class="wc-comment-footer"><div class="wc-footer-left"><span class="wc-vote-link wc-up  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-up fa-flip-horizontal wc-vote-img-up"></i><span>Daumen hoch</span></span><span class="wc-vote-result">0</span><span class="wc-vote-link wc-down  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-down wc-vote-img-down"></i><span>Daumen runter</span></span>&nbsp;</div><div class="wc-footer-right"><div class="wc-comment-date"><i class="fa fa-clock-o" aria-hidden="true"></i>7 Jahre 1 Monat her</div><div class="wc-toggle wpdiscuz-hidden"><i class="fa fa-chevron-up" aria-hidden="true"  title="Antworten verbergen"></i></div></div><div class="wpdiscuz_clear"></div></div></div><div class="wpdiscuz-comment-message"></div><div id="wpdiscuz_form_anchor-37166_0"  style="clear:both"></div></div><div id="wc-comm-37173_0" class="wc-comment wc-blog-guest wc_comment_level-1"><div class="wc-comment-left "><img class="avatar avatar-64 photo" width="64" height="64" src="https://www.drweb.de/magazin/wp-content/plugins/wpdiscuz/assets/img/trackback.png" alt="trackback"></div><div id="comment-37173" class="wc-comment-right " ><div class="wc-comment-header"><div class="wc-comment-author "><a rel='nofollow' href='http://www.webdesignzone.de/2010/05/09/interessantes-der-woche-2010-05-09/' target='_blank'>Interessantes der Woche (2010-05-09) | WebdesignZone</a></div><div class="wc-comment-link"><i class="fa fa-share-alt wc-share-link wpf-cta" aria-hidden="true" title="teilen" ></i><span class="share_buttons_box"><a class="wc_tw" target="_blank" href="https://twitter.com/home?status=" title=""><i class="fa fa-twitter wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a><a class="wc_go" target="_blank" href="https://plus.google.com/share?url=https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/" title=""><i class="fa fa-google wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a></span><span class="wc-comment-img-link-wrap"><i class="fa fa-link wc-comment-img-link wpf-cta" aria-hidden="true"/></i><span><input type="text" class="wc-comment-link-input" value="https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/#comment-37173" /></span></span></div><div class="wpdiscuz_clear"></div></div><div class="wc-comment-text"><p>[&#8230;] Design &#8211; 50 Free High Quality Icons <a href="http://goo.gl/Vy5c" rel="nofollow">http://goo.gl/Vy5c</a> #RT: @wowawebdesign: Gute Übersicht. <a href="http://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/" rel="nofollow">http://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/</a> #jquery #RT: @opera: Check out Icon Creator, a great tool to make professional looking Widgets [&#8230;]</p>
</div><div class="wc-comment-footer"><div class="wc-footer-left"><span class="wc-vote-link wc-up  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-up fa-flip-horizontal wc-vote-img-up"></i><span>Daumen hoch</span></span><span class="wc-vote-result">0</span><span class="wc-vote-link wc-down  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-down wc-vote-img-down"></i><span>Daumen runter</span></span>&nbsp;</div><div class="wc-footer-right"><div class="wc-comment-date"><i class="fa fa-clock-o" aria-hidden="true"></i>7 Jahre 1 Monat her</div><div class="wc-toggle wpdiscuz-hidden"><i class="fa fa-chevron-up" aria-hidden="true"  title="Antworten verbergen"></i></div></div><div class="wpdiscuz_clear"></div></div></div><div class="wpdiscuz-comment-message"></div><div id="wpdiscuz_form_anchor-37173_0"  style="clear:both"></div></div><div id="wc-comm-37201_0" class="wc-comment wc-blog-guest wc_comment_level-1"><div class="wc-comment-left "><img alt='ThomasO' src='https://secure.gravatar.com/avatar/2f846e3a88d3121e3329f6742a0fa606?s=64&#038;d=identicon&#038;r=pg' srcset='https://secure.gravatar.com/avatar/2f846e3a88d3121e3329f6742a0fa606?s=128&amp;d=identicon&amp;r=pg 2x' class='avatar avatar-64 photo' height='64' width='64' /><div class="wc-blog-guest wc-comment-label"><span>Gast</span></div></div><div id="comment-37201" class="wc-comment-right " ><div class="wc-comment-header"><div class="wc-comment-author "><a rel='nofollow' href='http://www.thomasoliver.de' target='_blank'>ThomasO</a></div><div class="wc-comment-link"><i class="fa fa-share-alt wc-share-link wpf-cta" aria-hidden="true" title="teilen" ></i><span class="share_buttons_box"><a class="wc_tw" target="_blank" href="https://twitter.com/home?status=" title=""><i class="fa fa-twitter wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a><a class="wc_go" target="_blank" href="https://plus.google.com/share?url=https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/" title=""><i class="fa fa-google wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a></span><span class="wc-comment-img-link-wrap"><i class="fa fa-link wc-comment-img-link wpf-cta" aria-hidden="true"/></i><span><input type="text" class="wc-comment-link-input" value="https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/#comment-37201" /></span></span></div><div class="wpdiscuz_clear"></div></div><div class="wc-comment-text"><p>Schöner Artikel mit interessanten Plugins.<br />
Habe mir wegen jQuery extra schon die aktuelle Video2Brain DVD zum Thema geholt und werde jQuery daher sicherlich immer öfter mit einbauen.</p>
</div><div class="wc-comment-footer"><div class="wc-footer-left"><span class="wc-vote-link wc-up  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-up fa-flip-horizontal wc-vote-img-up"></i><span>Daumen hoch</span></span><span class="wc-vote-result">0</span><span class="wc-vote-link wc-down  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-down wc-vote-img-down"></i><span>Daumen runter</span></span>&nbsp;</div><div class="wc-footer-right"><div class="wc-comment-date"><i class="fa fa-clock-o" aria-hidden="true"></i>7 Jahre 1 Monat her</div><div class="wc-toggle wpdiscuz-hidden"><i class="fa fa-chevron-up" aria-hidden="true"  title="Antworten verbergen"></i></div></div><div class="wpdiscuz_clear"></div></div></div><div class="wpdiscuz-comment-message"></div><div id="wpdiscuz_form_anchor-37201_0"  style="clear:both"></div></div><div id="wc-comm-37221_0" class="wc-comment wc-blog-guest wc_comment_level-1"><div class="wc-comment-left "><img alt='joe' src='https://secure.gravatar.com/avatar/2f4032f7348c5d0225384c5337255193?s=64&#038;d=identicon&#038;r=pg' srcset='https://secure.gravatar.com/avatar/2f4032f7348c5d0225384c5337255193?s=128&amp;d=identicon&amp;r=pg 2x' class='avatar avatar-64 photo' height='64' width='64' /><div class="wc-blog-guest wc-comment-label"><span>Gast</span></div></div><div id="comment-37221" class="wc-comment-right " ><div class="wc-comment-header"><div class="wc-comment-author ">joe</div><div class="wc-comment-link"><i class="fa fa-share-alt wc-share-link wpf-cta" aria-hidden="true" title="teilen" ></i><span class="share_buttons_box"><a class="wc_tw" target="_blank" href="https://twitter.com/home?status=" title=""><i class="fa fa-twitter wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a><a class="wc_go" target="_blank" href="https://plus.google.com/share?url=https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/" title=""><i class="fa fa-google wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a></span><span class="wc-comment-img-link-wrap"><i class="fa fa-link wc-comment-img-link wpf-cta" aria-hidden="true"/></i><span><input type="text" class="wc-comment-link-input" value="https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/#comment-37221" /></span></span></div><div class="wpdiscuz_clear"></div></div><div class="wc-comment-text">Finde es super das der Author noch auf dem Mootools eintag hinweisst von Herr Newton. Mootools ist meines erachtens das bessere Framework und ich finde es schade das überall nur über jquery berichtet wird. Klar jQery hat den Vorteil das ich nicht groß viel von Javascript wissen muss aber genau das führt auch zu dem falschen verwenden von Dom Zugriffen oder fehlerhaften Modulen die auf den Markt geworfen werden. Ich arbeite selbst viel mit jQery auf Arbeit da ich natürlich nicht 2 Frameworks in ein System hängen will. Ich merke nur das ich jQuery so oft an seine Grenzen bringe<span id="wpdiscuz-readmore-37221_0"><span class="wpdiscuz-hellip">&hellip;&nbsp;</span><span class="wpdiscuz-readmore" title="Read more »">Read more »</span></span></div><div class="wc-comment-footer"><div class="wc-footer-left"><span class="wc-vote-link wc-up  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-up fa-flip-horizontal wc-vote-img-up"></i><span>Daumen hoch</span></span><span class="wc-vote-result">0</span><span class="wc-vote-link wc-down  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-down wc-vote-img-down"></i><span>Daumen runter</span></span>&nbsp;</div><div class="wc-footer-right"><div class="wc-comment-date"><i class="fa fa-clock-o" aria-hidden="true"></i>7 Jahre 30 Tage her</div><div class="wc-toggle wpdiscuz-hidden"><i class="fa fa-chevron-up" aria-hidden="true"  title="Antworten verbergen"></i></div></div><div class="wpdiscuz_clear"></div></div></div><div class="wpdiscuz-comment-message"></div><div id="wpdiscuz_form_anchor-37221_0"  style="clear:both"></div></div><div id="wc-comm-37245_0" class="wc-comment wc-blog-guest wc_comment_level-1"><div class="wc-comment-left "><img alt='Tim Schindler' src='https://secure.gravatar.com/avatar/210a7d52c87d6167e5931866b672748e?s=64&#038;d=identicon&#038;r=pg' srcset='https://secure.gravatar.com/avatar/210a7d52c87d6167e5931866b672748e?s=128&amp;d=identicon&amp;r=pg 2x' class='avatar avatar-64 photo' height='64' width='64' /><div class="wc-blog-guest wc-comment-label"><span>Gast</span></div></div><div id="comment-37245" class="wc-comment-right " ><div class="wc-comment-header"><div class="wc-comment-author "><a rel='nofollow' href='http://www.my-escort-service.de' target='_blank'>Tim Schindler</a></div><div class="wc-comment-link"><i class="fa fa-share-alt wc-share-link wpf-cta" aria-hidden="true" title="teilen" ></i><span class="share_buttons_box"><a class="wc_tw" target="_blank" href="https://twitter.com/home?status=" title=""><i class="fa fa-twitter wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a><a class="wc_go" target="_blank" href="https://plus.google.com/share?url=https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/" title=""><i class="fa fa-google wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a></span><span class="wc-comment-img-link-wrap"><i class="fa fa-link wc-comment-img-link wpf-cta" aria-hidden="true"/></i><span><input type="text" class="wc-comment-link-input" value="https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/#comment-37245" /></span></span></div><div class="wpdiscuz_clear"></div></div><div class="wc-comment-text"><p>Ich finde die jQuery Plugins super. Vor allem von WordPress, was ich selbst verwende, gibt es einige interessante Codes die nützlich sein können. Aber bitte auf die Cpu Auslastung achten. =)</p>
<p>Lieben Gruß</p>
<p>Tim</p>
</div><div class="wc-comment-footer"><div class="wc-footer-left"><span class="wc-vote-link wc-up  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-up fa-flip-horizontal wc-vote-img-up"></i><span>Daumen hoch</span></span><span class="wc-vote-result">0</span><span class="wc-vote-link wc-down  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-down wc-vote-img-down"></i><span>Daumen runter</span></span>&nbsp;</div><div class="wc-footer-right"><div class="wc-comment-date"><i class="fa fa-clock-o" aria-hidden="true"></i>7 Jahre 28 Tage her</div><div class="wc-toggle wpdiscuz-hidden"><i class="fa fa-chevron-up" aria-hidden="true"  title="Antworten verbergen"></i></div></div><div class="wpdiscuz_clear"></div></div></div><div class="wpdiscuz-comment-message"></div><div id="wpdiscuz_form_anchor-37245_0"  style="clear:both"></div></div><div id="wc-comm-37247_0" class="wc-comment wc-blog-guest wc_comment_level-1"><div class="wc-comment-left "><img alt='Oliver' src='https://secure.gravatar.com/avatar/f0079573d5463d27b911cc9b6d403092?s=64&#038;d=identicon&#038;r=pg' srcset='https://secure.gravatar.com/avatar/f0079573d5463d27b911cc9b6d403092?s=128&amp;d=identicon&amp;r=pg 2x' class='avatar avatar-64 photo' height='64' width='64' /><div class="wc-blog-guest wc-comment-label"><span>Gast</span></div></div><div id="comment-37247" class="wc-comment-right " ><div class="wc-comment-header"><div class="wc-comment-author "><a rel='nofollow' href='http://www.olivertempel.de' target='_blank'>Oliver</a></div><div class="wc-comment-link"><i class="fa fa-share-alt wc-share-link wpf-cta" aria-hidden="true" title="teilen" ></i><span class="share_buttons_box"><a class="wc_tw" target="_blank" href="https://twitter.com/home?status=" title=""><i class="fa fa-twitter wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a><a class="wc_go" target="_blank" href="https://plus.google.com/share?url=https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/" title=""><i class="fa fa-google wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a></span><span class="wc-comment-img-link-wrap"><i class="fa fa-link wc-comment-img-link wpf-cta" aria-hidden="true"/></i><span><input type="text" class="wc-comment-link-input" value="https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/#comment-37247" /></span></span></div><div class="wpdiscuz_clear"></div></div><div class="wc-comment-text"><p>Dan ke für die schöne Zusammenfassung</p>
</div><div class="wc-comment-footer"><div class="wc-footer-left"><span class="wc-vote-link wc-up  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-up fa-flip-horizontal wc-vote-img-up"></i><span>Daumen hoch</span></span><span class="wc-vote-result">0</span><span class="wc-vote-link wc-down  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-down wc-vote-img-down"></i><span>Daumen runter</span></span>&nbsp;</div><div class="wc-footer-right"><div class="wc-comment-date"><i class="fa fa-clock-o" aria-hidden="true"></i>7 Jahre 28 Tage her</div><div class="wc-toggle wpdiscuz-hidden"><i class="fa fa-chevron-up" aria-hidden="true"  title="Antworten verbergen"></i></div></div><div class="wpdiscuz_clear"></div></div></div><div class="wpdiscuz-comment-message"></div><div id="wpdiscuz_form_anchor-37247_0"  style="clear:both"></div></div><div id="wc-comm-37297_0" class="wc-comment wc-blog-guest wc_comment_level-1"><div class="wc-comment-left "><img alt='Sonny' src='https://secure.gravatar.com/avatar/88b37c3f1d67cbd35985c851e877e7b5?s=64&#038;d=identicon&#038;r=pg' srcset='https://secure.gravatar.com/avatar/88b37c3f1d67cbd35985c851e877e7b5?s=128&amp;d=identicon&amp;r=pg 2x' class='avatar avatar-64 photo' height='64' width='64' /><div class="wc-blog-guest wc-comment-label"><span>Gast</span></div></div><div id="comment-37297" class="wc-comment-right " ><div class="wc-comment-header"><div class="wc-comment-author ">Sonny</div><div class="wc-comment-link"><i class="fa fa-share-alt wc-share-link wpf-cta" aria-hidden="true" title="teilen" ></i><span class="share_buttons_box"><a class="wc_tw" target="_blank" href="https://twitter.com/home?status=" title=""><i class="fa fa-twitter wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a><a class="wc_go" target="_blank" href="https://plus.google.com/share?url=https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/" title=""><i class="fa fa-google wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a></span><span class="wc-comment-img-link-wrap"><i class="fa fa-link wc-comment-img-link wpf-cta" aria-hidden="true"/></i><span><input type="text" class="wc-comment-link-input" value="https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/#comment-37297" /></span></span></div><div class="wpdiscuz_clear"></div></div><div class="wc-comment-text"><p>Gratulation, hervorragender Beitrag. Ich hoffe der nächste wird noch besser.</p>
</div><div class="wc-comment-footer"><div class="wc-footer-left"><span class="wc-vote-link wc-up  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-up fa-flip-horizontal wc-vote-img-up"></i><span>Daumen hoch</span></span><span class="wc-vote-result">0</span><span class="wc-vote-link wc-down  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-down wc-vote-img-down"></i><span>Daumen runter</span></span>&nbsp;</div><div class="wc-footer-right"><div class="wc-comment-date"><i class="fa fa-clock-o" aria-hidden="true"></i>7 Jahre 24 Tage her</div><div class="wc-toggle wpdiscuz-hidden"><i class="fa fa-chevron-up" aria-hidden="true"  title="Antworten verbergen"></i></div></div><div class="wpdiscuz_clear"></div></div></div><div class="wpdiscuz-comment-message"></div><div id="wpdiscuz_form_anchor-37297_0"  style="clear:both"></div></div><div id="wc-comm-38763_0" class="wc-comment wc-blog-guest wc_comment_level-1"><div class="wc-comment-left "><img class="avatar avatar-64 photo" width="64" height="64" src="https://www.drweb.de/magazin/wp-content/plugins/wpdiscuz/assets/img/trackback.png" alt="trackback"></div><div id="comment-38763" class="wc-comment-right " ><div class="wc-comment-header"><div class="wc-comment-author "><a rel='nofollow' href='http://www.blogmanufaktur.de/2010/07/28/jquery-die-interessantesten-aktuellen-plugins-und-tools/' target='_blank'>jQuery &#8211; die interessantesten aktuellen Plugins und Tools | blogmanufaktur</a></div><div class="wc-comment-link"><i class="fa fa-share-alt wc-share-link wpf-cta" aria-hidden="true" title="teilen" ></i><span class="share_buttons_box"><a class="wc_tw" target="_blank" href="https://twitter.com/home?status=" title=""><i class="fa fa-twitter wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a><a class="wc_go" target="_blank" href="https://plus.google.com/share?url=https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/" title=""><i class="fa fa-google wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a></span><span class="wc-comment-img-link-wrap"><i class="fa fa-link wc-comment-img-link wpf-cta" aria-hidden="true"/></i><span><input type="text" class="wc-comment-link-input" value="https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/#comment-38763" /></span></span></div><div class="wpdiscuz_clear"></div></div><div class="wc-comment-text"><p>[&#8230;] F&#252;r Dr. Web habe ich mir die interessantesten jQuery-Plugins und -Tools angesehen. [&#8230;]</p>
</div><div class="wc-comment-footer"><div class="wc-footer-left"><span class="wc-vote-link wc-up  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-up fa-flip-horizontal wc-vote-img-up"></i><span>Daumen hoch</span></span><span class="wc-vote-result">0</span><span class="wc-vote-link wc-down  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-down wc-vote-img-down"></i><span>Daumen runter</span></span>&nbsp;</div><div class="wc-footer-right"><div class="wc-comment-date"><i class="fa fa-clock-o" aria-hidden="true"></i>6 Jahre 10 Monate her</div><div class="wc-toggle wpdiscuz-hidden"><i class="fa fa-chevron-up" aria-hidden="true"  title="Antworten verbergen"></i></div></div><div class="wpdiscuz_clear"></div></div></div><div class="wpdiscuz-comment-message"></div><div id="wpdiscuz_form_anchor-38763_0"  style="clear:both"></div></div><div id="wc-comm-39144_0" class="wc-comment wc-blog-guest wc_comment_level-1"><div class="wc-comment-left "><img alt='seolar' src='https://secure.gravatar.com/avatar/fe6d4f4a22b93339c48053bd3a1dcbea?s=64&#038;d=identicon&#038;r=pg' srcset='https://secure.gravatar.com/avatar/fe6d4f4a22b93339c48053bd3a1dcbea?s=128&amp;d=identicon&amp;r=pg 2x' class='avatar avatar-64 photo' height='64' width='64' /><div class="wc-blog-guest wc-comment-label"><span>Gast</span></div></div><div id="comment-39144" class="wc-comment-right " ><div class="wc-comment-header"><div class="wc-comment-author "><a rel='nofollow' href='http://seolar.de' target='_blank'>seolar</a></div><div class="wc-comment-link"><i class="fa fa-share-alt wc-share-link wpf-cta" aria-hidden="true" title="teilen" ></i><span class="share_buttons_box"><a class="wc_tw" target="_blank" href="https://twitter.com/home?status=" title=""><i class="fa fa-twitter wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a><a class="wc_go" target="_blank" href="https://plus.google.com/share?url=https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/" title=""><i class="fa fa-google wpf-cta" aria-hidden="true"></i><span>Diesen Kommentar auf Twitter teilen?</span></a></span><span class="wc-comment-img-link-wrap"><i class="fa fa-link wc-comment-img-link wpf-cta" aria-hidden="true"/></i><span><input type="text" class="wc-comment-link-input" value="https://www.drweb.de/magazin/jquery-die-interessantesten-aktuellen-plugins-und-tools/#comment-39144" /></span></span></div><div class="wpdiscuz_clear"></div></div><div class="wc-comment-text"><p>Eine hervorragende Zusammenstellung wirklich schöner, interessanter und durchaus genialer Umsetzungen mit JQuery. Da ich selbst auch ein JQuery-Enthusiast bin, habe ich diese Listung absolut lieb gewonnen und direkt in meine Bookmark-Sammlung übernommen.</p>
<p>Danke für Deine Arbeit, die Dir wirklich gelungen ist!</p>
</div><div class="wc-comment-footer"><div class="wc-footer-left"><span class="wc-vote-link wc-up  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-up fa-flip-horizontal wc-vote-img-up"></i><span>Daumen hoch</span></span><span class="wc-vote-result">0</span><span class="wc-vote-link wc-down  wc_vote wc_not_clicked wc_tooltipster"><i class="fa fa-thumbs-down wc-vote-img-down"></i><span>Daumen runter</span></span>&nbsp;</div><div class="wc-footer-right"><div class="wc-comment-date"><i class="fa fa-clock-o" aria-hidden="true"></i>6 Jahre 9 Monate her</div><div class="wc-toggle wpdiscuz-hidden"><i class="fa fa-chevron-up" aria-hidden="true"  title="Antworten verbergen"></i></div></div><div class="wpdiscuz_clear"></div></div></div><div class="wpdiscuz-comment-message"></div><div id="wpdiscuz_form_anchor-39144_0"  style="clear:both"></div></div>                
                    <div class="wpdiscuz-comment-pagination">
                                            </div>
                </div>
                <div class="wpdiscuz_clear"></div>
                                                                            <div class="by-wpdiscuz">
                            <span id="awpdiscuz" onclick='javascript:document.getElementById("bywpdiscuz").style.display = "inline";
                                                    document.getElementById("awpdiscuz").style.display = "none";'>
                                <img alt="wpdiscuz" src="https://www.drweb.de/magazin/wp-content/plugins/wpdiscuz/assets/img/plugin-icon/icon_info.png"  align="absmiddle" class="wpdimg"/>
                            </span>&nbsp;
                            <a href="http://wpdiscuz.com/" target="_blank" id="bywpdiscuz" title="wpDiscuz v4.0.8 - Supercharged native comments">wpDiscuz</a>
                        </div>
                                                </div>
        </div>
        <div class="wpdiscuz-loading-bar wpdiscuz-loading-bar-unauth"><img class="wpdiscuz-loading-bar-img" alt="wpDiscuz" src="https://www.drweb.de/magazin/wp-content/plugins/wpdiscuz/assets/img/loading.gif" width="32" height="25" /></div>
        
	</div><!--/.pad-->
    </div><!-- end .post-title-main-inner -->
</section><!--/.content-->


        </div><!--/.main-inner-->
      </div><!--/.main-->
    </div><!--/.container-inner-->
  </div><!--/.container-->
        <div id="breadcrumbs">	Du bist hier:
<span xmlns:v="http://rdf.data-vocabulary.org/#"><span typeof="v:Breadcrumb"><a href="https://www.drweb.de/magazin/" rel="v:url" property="v:title">Home</a> / <span class="breadcrumb_last">jQuery &#8211; die interessantesten aktuellen Plugins und Tools</span></span></span></div>  
<div id="footer-line">
    <div class="footer-line-inner"></div>
</div>
  
  <footer id="footer">
                    
            <section class="container" id="footer-widgets">
          <div class="container-inner">
            
            <div class="pad group">

                                <div class="footer-widget-1 grid one-fourth ">
                    <div id="nav_menu-17" class="widget widget_nav_menu"><h3 class="widget-title">Ressorts</h3><div class="menu-footer-ressorts-container"><ul id="menu-footer-ressorts" class="menu"><li id="menu-item-58528" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-58528"><a href="https://www.drweb.de/magazin/wordpress/">WordPress</a></li>
<li id="menu-item-58527" class="menu-item menu-item-type-taxonomy menu-item-object-category current-post-ancestor current-menu-parent current-post-parent menu-item-58527"><a href="https://www.drweb.de/magazin/webdesign/">Webdesign</a></li>
<li id="menu-item-58529" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-58529"><a href="https://www.drweb.de/magazin/design/">Design</a></li>
<li id="menu-item-58526" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-58526"><a href="https://www.drweb.de/magazin/inspiration/">Inspiration</a></li>
</ul></div></div>                  </div>
                                <div class="footer-widget-2 grid one-fourth ">
                    <div id="text-36" class="widget widget_text"><h3 class="widget-title">Schlagworte</h3>			<div class="textwidget"><ul class="tagnav"><li><a href="https://www.drweb.de/magazin/tag/#taglist__A" title="A">A</a></li><li><a href="https://www.drweb.de/magazin/tag/#taglist__B" title="B">B</a></li><li><a href="https://www.drweb.de/magazin/tag/#taglist__C" title="C">C</a></li><li><a href="https://www.drweb.de/magazin/tag/#taglist__D" title="D">D</a></li><li><a href="https://www.drweb.de/magazin/tag/#taglist__E" title="E">E</a></li><li><a href="https://www.drweb.de/magazin/tag/#taglist__F" title="F">F</a></li><li><a href="https://www.drweb.de/magazin/tag/#taglist__G" title="G">G</a></li><li><a href="https://www.drweb.de/magazin/tag/#taglist__H" title="H">H</a></li><li><a href="https://www.drweb.de/magazin/tag/#taglist__I" title="I">I</a></li><li><a href="https://www.drweb.de/magazin/tag/#taglist__J" title="J">J</a></li><li><a href="https://www.drweb.de/magazin/tag/#taglist__K" title="K">K</a></li><li><a href="https://www.drweb.de/magazin/tag/#taglist__L" title="L">L</a></li><li><a href="https://www.drweb.de/magazin/tag/#taglist__M" title="M">M</a></li><li><a href="https://www.drweb.de/magazin/tag/#taglist__N" title="N">N</a></li><li><a href="https://www.drweb.de/magazin/tag/#taglist__O" title="O">O</a></li><li><a href="https://www.drweb.de/magazin/tag/#taglist__P" title="P">P</a></li><li><a href="https://www.drweb.de/magazin/tag/#taglist__Q" title="Q">Q</a></li><li><a href="https://www.drweb.de/magazin/tag/#taglist__R" title="R">R</a></li><li><a href="https://www.drweb.de/magazin/tag/#taglist__S" title="S">S</a></li><li><a href="https://www.drweb.de/magazin/tag/#taglist__T" title="T">T</a></li><li><a href="https://www.drweb.de/magazin/tag/#taglist__U" title="U">U</a></li><li><a href="https://www.drweb.de/magazin/tag/#taglist__V" title="V">V</a></li><li><a href="https://www.drweb.de/magazin/tag/#taglist__W" title="W">W</a></li><li><a href="https://www.drweb.de/magazin/tag/#taglist__X" title="X">X</a></li><li><a href="https://www.drweb.de/magazin/tag/#taglist__Y" title="Y">Y</a></li></ul><div class="clear"></div></div>
		</div>                  </div>
                                <div class="footer-widget-3 grid one-fourth ">
                    <div id="nav_menu-18" class="widget widget_nav_menu"><h3 class="widget-title">Soziales</h3><div class="menu-footer-soziales-container"><ul id="menu-footer-soziales" class="menu"><li id="menu-item-76137" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-76137"><a href="https://www.facebook.com/DrWebMagazin">Facebook</a></li>
<li id="menu-item-76138" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-76138"><a href="https://twitter.com/drwebmagazin">Twitter</a></li>
<li id="menu-item-76139" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-76139"><a href="https://plus.google.com/103443335248647770600">Google+</a></li>
<li id="menu-item-76140" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-76140"><a href="http://feeds.feedburner.com/drwebmagazin">RSS-Feed</a></li>
</ul></div></div>                  </div>
                                <div class="footer-widget-4 grid one-fourth last">
                    <div id="nav_menu-19" class="widget widget_nav_menu"><h3 class="widget-title">Shop</h3><div class="menu-shop-footer-container"><ul id="menu-shop-footer" class="menu"><li id="menu-item-82818" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-82818"><a href="https://www.drweb.de/magazin/shop/">Shop</a></li>
<li id="menu-item-82815" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-82815"><a href="https://www.drweb.de/magazin/allgemeine_geschaeftsbedingungen/">Allgemeine Geschäftsbedingungen</a></li>
<li id="menu-item-82813" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-82813"><a href="https://www.drweb.de/magazin/kundeninformationen/">Kundeninformationen</a></li>
<li id="menu-item-82814" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-82814"><a href="https://www.drweb.de/magazin/datenschutz/">Datenschutz</a></li>
<li id="menu-item-82816" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-82816"><a href="https://www.drweb.de/magazin/zahlungsweisen/">Zahlungsweisen</a></li>
<li id="menu-item-82817" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-82817"><a href="https://www.drweb.de/magazin/widerruf/">Widerruf</a></li>
</ul></div></div>                  </div>
              
            </div><!--/.pad-->

          </div><!--/.container-inner-->
        </section><!--/.container-->

    
            <nav class="nav-container group" id="nav-footer">
        <div class="nav-toggle"><i class="fa fa-bars"></i></div>
        <div class="nav-text"><!-- put your mobile menu text here --></div>
        <div class="nav-wrap"><ul id="menu-footer-menu" class="nav container group"><li id="menu-item-61582" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-61582"><a href="https://www.drweb.de/magazin/autoren/">Autoren</a></li>
<li id="menu-item-29828" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-29828"><a href="https://www.drweb.de/magazin/kontakt/">Kontakt</a></li>
<li id="menu-item-29829" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-29829"><a href="https://www.drweb.de/magazin/impressum/">Impressum</a></li>
<li id="menu-item-53762" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-53762"><a href="https://www.drweb.de/magazin/hier-werben/">Hier werben</a></li>
<li id="menu-item-82594" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-82594"><a href="https://www.drweb.de/magazin/sponsored-post/">Sponsored Post</a></li>
<li id="menu-item-82595" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-82595"><a href="https://www.drweb.de/magazin/newsletter/">Newsletter</a></li>
</ul></div>
      </nav><!--/#nav-footer-->
    

    <section class="container" id="footer-bottom">
      <div class="container-inner">

        <div class="pad group">

          <div class="grid one-half">
                                      
            
            <div id="copyright">
             <p>&copy; 1997 - 2017 - drweb.de, gegründet von Sven Lennartz.</p>
            </div><!--/#copyright-->

          </div>

          <div class="grid one-half last">
            <p><a href="//www.noupe.com" target="_blank" class="footer-text__noupe">dr. web <i class="fa fa-heart" aria-hidden="true"></i> noupe</a></p>
          </div>

        </div><!--/.pad-->

      </div><!--/.container-inner-->
    </section><!--/.container-->

  </footer><!--/#footer-->

</div><!--/#wrapper-->

<script type='text/javascript'>
var colomatduration = 'fast';
var colomatslideEffect = 'slideFade';
</script><!--Enhanced Ecommerce Google Analytics Plugin for Woocommerce by Tatvic Plugin Version:1.0.21--><div class="wpdiscuz-mod-email"></div><div class="wpdiscuz-mod-email-form" style="display: none;"><span class="wpdiscuz-mod-author">You are going to send email to <em></em></span><i class="fa fa-times"></i><div style="clear: both;"></div><input placeholder="Email Subject" type="text" class="wpdiscuz-mod-subj" value="" /><textarea class="wpdiscuz-mod-msg" placeholder="Enter your message here"></textarea><br /><div class="wpdiscuz-mod-button-align"><button type="button" class="wpdiscuz-mod-send">Send</button></div></div><div class="wpdiscuz-mod-moving" style="display: none;"></div><div class="wpdiscuz-mod-move-form" style="display: none;"><span class="wpdiscuz-mod-author">Move Comment<br /><em></em></span><i class="fa fa-times"></i><div style="clear: both;"></div><div style="position: relative;"><input type="text" class="wpdiscuz-mod-post" placeholder="Enter post title..." /><div class="wpdiscuz-mod-posts"></div></div><div class="wpdiscuz-mod-button-align"><button type="button" class="wpdiscuz-mod-move">Move</button></div></div>
<script type='text/javascript'>
/* <![CDATA[ */
var cnArgs = {"ajaxurl":"https:\/\/www.drweb.de\/magazin\/wp-admin\/admin-ajax.php","hideEffect":"fade","onScroll":"no","onScrollOffset":"100","cookieName":"cookie_notice_accepted","cookieValue":"TRUE","cookieTime":"2592000","cookiePath":"\/magazin\/","cookieDomain":""};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.drweb.de/magazin/wp-content/plugins/cookie-notice/js/front.js'></script>
<script type='text/javascript' src='https://www.drweb.de/magazin/wp-content/plugins/jquery-collapse-o-matic/js/collapse.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/magazin\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/magazin\/jquery-die-interessantesten-aktuellen-plugins-und-tools\/?wc-ajax=%%endpoint%%","i18n_view_cart":"Warenkorb anzeigen","cart_url":"https:\/\/www.drweb.de\/magazin\/warenkorb\/","is_cart":"","cart_redirect_after_add":"yes"};
/* ]]> */
</script>
<script type='text/javascript' src='//www.drweb.de/magazin/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js'></script>
<script type='text/javascript' src='//www.drweb.de/magazin/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js'></script>
<script type='text/javascript' src='//www.drweb.de/magazin/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/magazin\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/magazin\/jquery-die-interessantesten-aktuellen-plugins-und-tools\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='//www.drweb.de/magazin/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/magazin\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/magazin\/jquery-die-interessantesten-aktuellen-plugins-und-tools\/?wc-ajax=%%endpoint%%","fragment_name":"wc_fragments"};
/* ]]> */
</script>
<script type='text/javascript' src='//www.drweb.de/magazin/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js'></script>
<script type='text/javascript' src='https://www.drweb.de/magazin/wp-includes/js/jquery/jquery.form.min.js'></script>
<script type='text/javascript' src='https://www.drweb.de/magazin/wp-includes/js/underscore.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var HUParams = {"_disabled":[],"SmoothScroll":{"Enabled":false,"Options":{"touchpadSupport":false}},"centerAllImg":"1","timerOnScrollAllBrowsers":"1","extLinksStyle":"1","extLinksTargetExt":"1","extLinksSkipSelectors":{"classes":["btn","button"],"ids":[]},"imgSmartLoadEnabled":null,"imgSmartLoadOpts":{"parentSelectors":[".container .content",".container .sidebar","#footer","#header-widgets"],"opts":{"excludeImg":[".tc-holder-img"],"fadeIn_options":100}},"goldenRatio":"1.618","gridGoldenRatioLimit":"350","vivusSvgSpeed":"300","isDevMode":""};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.drweb.de/magazin/wp-content/themes/drweb/assets/front/js/scripts.min.js'></script>
<script type='text/javascript' src='https://www.drweb.de/magazin/wp-content/themes/drweb/js/ads-controller-min.js'></script>
<script type='text/javascript' src='https://www.drweb.de/magazin/wp-content/themes/drweb/js/ads-drweb.js'></script>
<script type='text/javascript' src='https://www.drweb.de/magazin/wp-content/plugins/shariff/js/shariff.min.js'></script>
<script type='text/javascript' src='https://www.drweb.de/magazin/wp-content/plugins/shariff/js/shariff-popup.min.js'></script>
<!--[if lt IE 9]>
<script src="https://www.drweb.de/magazin/wp-content/themes/drweb/assets/front/js/ie/respond.js"></script>
<![endif]-->
<!-- WooCommerce JavaScript -->
<script type="text/javascript">
jQuery(function($) { 
tvc_lc="EUR";

homepage_json_ATC_link=[];

tvc_fp=[];

tvc_rcp=[];

tvc_rdp=[];

prodpage_json_ATC_link=[];

tvc_pgc=[];

catpage_json_ATC_link=[];

tvc_smd={"tvc_wcv":"3.0.8","tvc_wpv":"4.8","tvc_eev":"1.0.21","tvc_cnf":{"t_ee":"yes","t_df":false,"t_gUser":true,"t_UAen":"no","t_thr":"6"}};
 });
</script>

			<div id="cookie-notice" role="banner" class="cn-bottom bootstrap" style="color: #fff; background-color: #000;"><div class="cookie-notice-container"><span id="cn-notice-text">Diese Website benutzt Cookies. Wenn du die Website weiter nutzt, gehen wir von deinem Einverständnis aus.</span><a href="#" id="cn-accept-cookie" data-cookie-set="accept" class="cn-set-cookie button bootstrap">Okay!</a>
				</div>
			</div>
<link href="//opensource.keycdn.com/fontawesome/4.7.0/font-awesome.min.css" rel="stylesheet" />

<!-- Dr. Web AD - Scripts -->
<div id="content-sponsors" data-ad-zone-id="119" data-ad-group="content-sponsors" data-ad-list="3" data-ad-mixin-zone-id="120" data-ad-mixin-list="1" data-ad-fetchonly="true"></div>
<div id="layerad_all" data-ad-zone-id="118"><!-- Layer ad zone on all pages --></div>
	<div id="layerad" data-ad-zone-id="83"><!-- Layer ad zone on older articles --></div>

<!-- Place as early in the document as possible, but not before the last ad target. -->
<script type='text/javascript'>/* <![CDATA[ */  AdsController.load();   /* ]]> */</script>
<script type='text/javascript'>/* <![CDATA[ */  AdsController.postLoad();   /* ]]> */</script>
<script type='text/javascript'>/* <![CDATA[ */  AdsController.postPostLoad();   /* ]]> */</script>
</body>
</html>
