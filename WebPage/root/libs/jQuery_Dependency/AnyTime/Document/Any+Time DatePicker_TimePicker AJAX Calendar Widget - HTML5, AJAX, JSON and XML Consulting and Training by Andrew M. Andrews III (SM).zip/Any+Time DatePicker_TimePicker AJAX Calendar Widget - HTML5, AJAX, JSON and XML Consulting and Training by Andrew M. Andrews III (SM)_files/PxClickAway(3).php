<!DOCTYPE html>
<html>
<head>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>tardate 2017</title>
    <link rel="dns-prefetch" href="//maxcdn.bootstrapcdn.com">
    <link rel="dns-prefetch" href="//cdn.mathjax.org">
    <link rel="dns-prefetch" href="//cdnjs.cloudflare.com">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="This blog is my occasional diary of Quite Interesting Things. It is generally technical, meaning all things web, open source, polyglot-programming, electronics and concerning data. But sometimes ravings on books or musics, and occasionally a rant or philosophical dribble.
">
    <meta name="robots" content="all">
    <meta name="author" content="Paul Gallagher">
    
    
    <link rel="canonical" href="http://blog.tardate.com/">
    <link rel="alternate" type="application/rss+xml" title="RSS Feed for tardate 2017" href="/feed.xml" />

    <!-- Custom CSS -->
    <link rel="stylesheet" href="/css/site.css?201706121454" type="text/css">

    <!-- Fonts -->
    
    <link href='//fonts.googleapis.com/css?family=Merriweather:900,900italic,300,300italic' rel='stylesheet' type='text/css'>
    <link href='//fonts.googleapis.com/css?family=Lato:900,300' rel='stylesheet' type='text/css'>
    
    
      <link href="//maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    

    <!-- MathJax -->
    

    <!-- Verifications -->
    
    

    <!-- Open Graph -->
    <!-- From: https://github.com/mmistakes/hpstr-jekyll-theme/blob/master/_includes/head.html -->
    <meta property="og:locale" content="en_US">
    <meta property="og:type" content="article">
    <meta property="og:title" content="tardate 2017">
    <meta property="og:description" content="This blog is my occasional diary of Quite Interesting Things. It is generally technical, meaning all things web, open source, polyglot-programming, electronics and concerning data. But sometimes ravings on books or musics, and occasionally a rant or philosophical dribble.
">
    <meta property="og:url" content="http://blog.tardate.com/">
    <meta property="og:site_name" content="tardate 2017">

    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary" />
    
        <meta name="twitter:site" content="@tardate" />
    
    <meta name="twitter:title" content="tardate 2017" />
    <meta name="twitter:description" content="This blog is my occasional diary of Quite Interesting Things. It is generally technical, meaning all things web, open source, polyglot-programming, electronics and concerning data. But sometimes ravings on books or musics, and occasionally a rant or philosophical dribble.
" />
    <meta name="twitter:url" content="http://blog.tardate.com/" />
    

    <!-- Icons -->
    <link rel="apple-touch-icon" sizes="57x57" href="/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon-180x180.png">
    <link rel="icon" type="image/png" href="/favicon-192x192.png" sizes="192x192">
    <link rel="icon" type="image/png" href="/favicon-160x160.png" sizes="160x160">
    <link rel="icon" type="image/png" href="/favicon-96x96.png" sizes="96x96">
    <link rel="icon" type="image/png" href="/favicon-16x16.png" sizes="16x16">
    <link rel="icon" type="image/png" href="/favicon-32x32.png" sizes="32x32">

    
    <script type="text/javascript">
       (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
       (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
       m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
       })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
       ga('create', 'UA-4894631-1', 'auto');
       ga('send', 'pageview');
    </script>
    
</head>

<body class="site animated fade-in-down">
  
	

  <div class="site-wrap">
    <header class="site-header px2 px-responsive">
  <div class="mt2 wrap">
    <div class="measure">
      <a href="http://blog.tardate.com" class="site-title">tardate 2017</a>
      <nav class="site-nav">
        
    

    
        <a href="/about/">About</a>
    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    


    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    


      </nav>
      <div class="clearfix"></div>
      
        <div class="social-icons">
  <div class="social-icons-left">
      <a href="http://leap.tardate.com/" title="a collection of electronics projects, often involving an Arduino">LittleArduinoProjects</a>
      <a href="http://codingkata.tardate.com/" title="my notes and test code on software development topics and tools">LittleCodingKata</a>
  </div>
  <div class="social-icons-right">
    
      <a class="fa fa-github" href="https://github.com/tardate"></a>
    
    
    
      <a class="fa fa-stack-overflow" href="https://stackoverflow.com/users/6329"></a>
    
    <a class="fa fa-rss" href="/feed.xml"></a>
    
      <a class="fa fa-twitter" href="https://twitter.com/tardate"></a>
    
    
    
    
    
      <a class="fa fa-envelope" href="mailto:gallagher.paul@gmail.com"></a>
    
    
      <a class="fa fa-linkedin" href="https://www.linkedin.com/in/gallagherpaul"></a>
    
    
    
  </div>
  <div class="right">
    
    
    
  </div>
</div>
<div class="clearfix"></div>

      
  </div>
</header>


    <div class="post p2 p-responsive wrap" role="main">
      <div class="measure">
        

<div id="gr_grid_widget_1447164563" class="recent-reads">
  <h2>
    <a style="text-decoration: none;" href="https://www.goodreads.com/review/list/17475014-paul?shelf=read&utm_medium=api&utm_source=grid_widget">my recent reads..</a>
  </h2>
  <div class="gr_grid_container"/>
    <noscript><br/>Share <a href="https://www.goodreads.com/review/list/17475014-paul">book reviews</a> and ratings with Paul on Goodreads.</noscript>
  </div>
</div>
<div class="clearfix"></div>

<div class="home">
  
    <div class="posts">
      
        <div class="post py3">
          <p class="post-meta">Jun 12, 2017 
<span class="label label-primary">Electronics</span>

<span class="label label-primary">555</span>
</p>
          <a href="/2017/06/leap319-digital-logic-clock.html" class="post-link"><h3 class="h1 post-title">LEAP#319 Digital Logic Clock</h3></a>
          <p class="post-summary">
            <p>This digital clock module was <a href="https://www.youtube.com/watch?v=SmQ5K7UQPMM">designed by Ben Eater</a> as part of his 8-bit computer build.
It is also an interesting demonstration of the 555 timer in all its major modes of operation.
As always, <a href="https://github.com/tardate/LittleArduinoProjects/tree/master/Electronics101/555Timer/DigitalLogicClock">all notes, schematics and code are in the Little Electronics &amp; Arduino Projects repo on GitHub</a>
<a href="https://github.com/tardate/LittleArduinoProjects/tree/master/Electronics101/555Timer/DigitalLogicClock"><img src="http://leap.tardate.com/Electronics101/555Timer/DigitalLogicClock/assets/DigitalLogicClock_build.jpg" alt="hero_image" /></a></p>


            <br>
            <a href="/2017/06/leap319-digital-logic-clock.html" class="post-link more">read more and comment..</a>
          </p>
        </div>
      
        <div class="post py3">
          <p class="post-meta">Jun 7, 2017 
<span class="label label-primary">Electronics</span>

<span class="label label-primary">555</span>
</p>
          <a href="/2017/06/leap318-555-bistable-latch.html" class="post-link"><h3 class="h1 post-title">LEAP#318 555 Bistable Latch</h3></a>
          <p class="post-summary">
            <p>Ben Eater’s 8-bit computer yields more interesting circuits.
Here I’m reproducing his <a href="https://www.youtube.com/watch?v=WCwJNnx36Rk">bistable latch circuit based on the 555 timer</a>.
This circuit takes advantage of the fact that the trigger and reset pins provide direct access to the SR latch within the 555 timer that drives the output.
As always, <a href="https://github.com/tardate/LittleArduinoProjects/tree/master/Electronics101/555Timer/Bistable">all notes, schematics and code are in the Little Electronics &amp; Arduino Projects repo on GitHub</a>
<a href="https://github.com/tardate/LittleArduinoProjects/tree/master/Electronics101/555Timer/Bistable"><img src="http://leap.tardate.com/Electronics101/555Timer/Bistable/assets/Bistable_build.jpg" alt="hero_image" /></a></p>


            <br>
            <a href="/2017/06/leap318-555-bistable-latch.html" class="post-link more">read more and comment..</a>
          </p>
        </div>
      
        <div class="post py3">
          <p class="post-meta">Jun 6, 2017 
<span class="label label-primary">Electronics</span>
</p>
          <a href="/2017/06/leap317-discrete-schmitt-trigger.html" class="post-link"><h3 class="h1 post-title">LEAP#317 Discrete Schmitt Trigger</h3></a>
          <p class="post-summary">
            <p>A Schmitt trigger is a comparator circuit with hysteresis,
which can help overcome the effect of noise or oscillations on an input signal
and provide positive switching between high and low logic levels.
Schmitt triggers are often built into the input pins of integrated circuits.
Stand-alone Schmitt triggers are usually constructed from comparators.
The most basic Schmitt trigger can be implemented with discrete components,
and here I’m exploring a classic emitter-coupled Schmitt Trigger circuit.
As always, <a href="https://github.com/tardate/LittleArduinoProjects/tree/master/Electronics101/SchmittTrigger/BasicDiscrete">all notes, schematics and code are in the Little Electronics &amp; Arduino Projects repo on GitHub</a>
<a href="https://github.com/tardate/LittleArduinoProjects/tree/master/Electronics101/SchmittTrigger/BasicDiscrete"><img src="http://leap.tardate.com/Electronics101/SchmittTrigger/BasicDiscrete/assets/BasicDiscrete_build.jpg" alt="hero_image" /></a></p>


            <br>
            <a href="/2017/06/leap317-discrete-schmitt-trigger.html" class="post-link more">read more and comment..</a>
          </p>
        </div>
      
        <div class="post py3">
          <p class="post-meta">Jun 5, 2017 
<span class="label label-primary">Electronics</span>

<span class="label label-primary">BoldportClub</span>
</p>
          <a href="/2017/06/leap316-the-boldport-qsop-breakout.html" class="post-link"><h3 class="h1 post-title">LEAP#316 The Boldport QSOP Breakout</h3></a>
          <p class="post-summary">
            <p>The QSOPBreakout was a special (read: beautiful!) board produced for the Boldport Club to help members
practice QSOP-24 soldering techniques for the Touchy project.
Firstly, I’m using this project to collate my notes on solder technique.
And secondly, perhaps there is something useful I can do with the QSOPBreakout board after all .. other than use it as a breakout board of course. And it turns out there is .. see the <a href="https://github.com/tardate/LittleArduinoProjects/tree/master/BoldportClub/QSOPBreakout/SolarPendulum">SolarPendulum</a>!
As always, <a href="https://github.com/tardate/LittleArduinoProjects/tree/master/BoldportClub/QSOPBreakout">all notes, schematics and code are in the Little Electronics &amp; Arduino Projects repo on GitHub</a>
<a href="https://github.com/tardate/LittleArduinoProjects/tree/master/BoldportClub/QSOPBreakout"><img src="http://leap.tardate.com/BoldportClub/QSOPBreakout/assets/QSOPBreakout_build.jpg" alt="hero_image" /></a></p>


            <br>
            <a href="/2017/06/leap316-the-boldport-qsop-breakout.html" class="post-link more">read more and comment..</a>
          </p>
        </div>
      
    </div>

    <div class="pagination clearfix mb1 mt4">
  <div class="left">
    
      <span class="pagination-item disabled">Newer</span>
    
  </div>
  <div class="right">
    
      <a class="pagination-item" href="/page2">Older</a>
    
  </div>
  <div class="pagination-meta">Page 1 of 131</div>
</div>

  
</div>

<script src="https://www.goodreads.com/review/grid_widget/17475014.my%20recent%20reads..?cover_size=medium&hide_link=true&hide_title=&num_books=8&order=d&shelf=read&sort=date_read&widget_id=1447164563" type="text/javascript" charset="utf-8"></script>

      </div>
    </div>
  </div>

  <footer class="center">
  <div class="measure">
    
      <div class="social-icons">
  <div class="social-icons-left">
      <a href="http://leap.tardate.com/" title="a collection of electronics projects, often involving an Arduino">LittleArduinoProjects</a>
      <a href="http://codingkata.tardate.com/" title="my notes and test code on software development topics and tools">LittleCodingKata</a>
  </div>
  <div class="social-icons-right">
    
      <a class="fa fa-github" href="https://github.com/tardate"></a>
    
    
    
      <a class="fa fa-stack-overflow" href="https://stackoverflow.com/users/6329"></a>
    
    <a class="fa fa-rss" href="/feed.xml"></a>
    
      <a class="fa fa-twitter" href="https://twitter.com/tardate"></a>
    
    
    
    
    
      <a class="fa fa-envelope" href="mailto:gallagher.paul@gmail.com"></a>
    
    
      <a class="fa fa-linkedin" href="https://www.linkedin.com/in/gallagherpaul"></a>
    
    
    
  </div>
  <div class="right">
    
    
    
  </div>
</div>
<div class="clearfix"></div>

    
  </div>
</footer>


</body>
</html>
