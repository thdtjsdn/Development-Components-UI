<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name=viewport content="width=device-width, initial-scale=1">
<title>Download Any+Time Date / Time Picker - TechnoGadge</title>
<link rel='shortlink' href='http://www.technogadge.com/?p=1762' />
<meta name="robots" content="index,follow,noodp,noydir" >
<meta name="description" content="Looking for a DatePicker / TimePicker script? Try Any+Time, a free JavaScript Library that will not only let you create a date/time picker with advanced" >
<meta name="keywords" content="Any+Time,Date Picker,JavaScript,jQuery,Scripts,Time Picker" >
<link rel="canonical" href="http://www.technogadge.com/download-anytime-date-time-picker/" >
<link rel="stylesheet" href="http://www.technogadge.com/assets/style.css" type="text/css" media="screen" >
<link rel="shortcut icon" href="http://www.technogadge.com/favicon.ico">
</head>

<body id="technogadge-com">
<div id="page">
<header>
<nav><div id="navbar"><div class="main-menu"><ul><li class="logo"><a href="http://www.technogadge.com" title="Technogadge" rel="home">Technogadge</a></li><li class="cat"><a href="http://www.technogadge.com/category/computer/" title="Computer Help Articles">Computer</a></li> <li class="cat"><a href="http://www.technogadge.com/category/internet/" title="Internet related articles">Internet</a></li> <li class="cat"><a href="http://www.technogadge.com/category/software/" title="Freeware Software downloads">Software</a></li> <li class="cat"><a href="http://www.technogadge.com/category/scripts/" title="Free Website Scripts">Scripts</a></li><li class="cat"><a href="http://www.technogadge.com/category/firefox/" title="Firefox Help Articles">Firefox</a></li><li class="cat"><a href="http://www.technogadge.com/archives/" title="Technogadge Archives">Archives</a></li><li class="search-box"><form method="get" class="searchform" action="http://www.technogadge.com/"><input type="text" value="Search" name="s" id="s" onblur="if (this.value == '') {this.value = 'Search';}" onfocus="if (this.value == 'Search') {this.value = '';}" /><input type="submit" id="searchsubmit" value="GO"/></form></li></ul></div></div></nav>
</header>

<div id="main">
<div class="box-c">

</div>
<section id="post-content">
<div id="primary"><div id="content">
<div id="breadcrumbs"><a href="http://www.technogadge.com" title="Technogadge.com Homepage">Home</a> > <a href="http://www.technogadge.com/category/scripts/" title="View all posts in Scripts" rel="category tag">Scripts</a> > Download Any+Time Date / Time Picker</div> 
<article id="post-1762">
<h1 class="entry-title">Download Any+Time Date / Time Picker</h1>
<span class="time">May 3, 2010</span>
<div class="entry-content">
<p align="justify">Looking for a <strong>DatePicker / TimePicker</strong> script? Try <strong>Any+Time</strong>, a free JavaScript Library that will not only let you create a date/time picker with advanced features and options but will also allow you to format dates and times the way you want! Any+Time uses <strong>jQuery</strong> JavaScript Library. It is extremely easy to use and comes with many styling options. </p>
<p align="center"><img style="margin: 0px 5px 0px 0px" height="246" alt="Any Time jQuery" src="http://technogadge.com/wp-content/uploads/2010/05/Any+Time-jQuery.jpg" width="398" border="0" /> </p>
<p align="justify">Date/Time options in <strong>Any+Time</strong> includes 12-hour or 24-hour clock, custom date/time format, date/time range limits, UTC offsets/time zones, era-selection (BCE/CE, BC/AD, etc.), start week on any day, date-only, time-only, or specific fields and custom base for 2-digit years (1900, 2000, etc.). Styling options include custom labels/languages, custom CSS styles, jQuery UI Theming, jQuery UI Theme Switcher, jQuery ThemeRoller, pop-up or always-present picker and visible or hidden field. For ease in use, Any+Time offers single-click value selection and double-click select-and-dismiss features. </p>
<p align="justify">Any+Time has been tested and found compatible with Chrome 4.1, Firefox 3.6, Internet Explorer 8.0, Opera 10.51 and Safari 4.0. So, get it today! </p>
<p align="justify"><strong>More Info and Download Link:</strong> <a href="http://www.ama3.com/anytime/" target="_blank" rel="nofollow">http://www.ama3.com/anytime/</a></p>
</div>
<aside id="post-meta">
<div class="entry-meta"><p>This article was written by <span class="author">Sandy</span>. Last update on May 3, 2010</p><p>Tags: <a href="http://www.technogadge.com/tag/anytime/" rel="tag">Any+Time</a>, <a href="http://www.technogadge.com/tag/date-picker/" rel="tag">Date Picker</a>, <a href="http://www.technogadge.com/tag/javascript/" rel="tag">JavaScript</a>, <a href="http://www.technogadge.com/tag/jquery/" rel="tag">jQuery</a>, <a href="http://www.technogadge.com/tag/scripts/" rel="tag">Scripts</a>, <a href="http://www.technogadge.com/tag/time-picker/" rel="tag">Time Picker</a></p></div>
</aside>

<div id="comments">
 
<div id="respond">
<h3>Leave a Reply</h3> 
 
<form action="http://www.technogadge.com/wp-comments-post.php" method="post" id="commentform">

<label for="author">Name <span class="req">*</span></label>
<input type="text" name="author" id="author" value="" size="22" tabindex="1" aria-required='true' />
<label for="email">Email <span class="req">*</span></label>
<input type="text" name="email" id="email" value="" size="22" tabindex="2" aria-required='true' />
<label for="url">Website (Optional)</label>
<input type="text" name="url" id="url" value="" size="22" tabindex="3" />
<label for="comment">Comment Text <span class="req">*</span></label>
<textarea name="comment" id="comment" cols="40" rows="10" tabindex="4"></textarea>
<p><strong>Note:</strong> The sign <span class="req">*</span> means required field. Comments are subject to moderation.</p>
<input name="submit" type="submit" id="submit" tabindex="5" value="Submit Comment">
<input type='hidden' name='comment_post_ID' value='1762' id='comment_post_ID' />
<input type='hidden' name='comment_parent' id='comment_parent' value='0' />

<p style="display: none;"><input type="hidden" id="akismet_comment_nonce" name="akismet_comment_nonce" value="3e7749cfac" /></p><script type='text/javascript' src='http://www.technogadge.com/wp-includes/js/jquery/jquery.js?ver=1.4.4'></script>
<script type='text/javascript' src='http://www.technogadge.com/wp-content/plugins/akismet/_inc/form.js?ver=3.0.0'></script>
<p style="display: none;"><input type="hidden" id="ak_js" name="ak_js" value="169"/></p></form>
 
</div>
 
</div><!-- #comments -->
</article>
      		
				
</div></div>
</section>
<aside>
<div id="sidebar" class="widget-area">
<div class="box-c">

</div><div id="follow">
<p>Get Free email updates!</p>
<form action="http://feedburner.google.com/fb/a/mailverify" method="post" target="popupwindow" onsubmit="window.open('http://feedburner.google.com/fb/a/mailverify?uri=', 'popupwindow', 'scrollbars=yes,width=550,height=520');return true" class="fe">
<input type="email" onblur="if (this.value == '') {this.value = 'Your email address';}" onfocus="if (this.value == 'Your email address') {this.value = '';}" value="Your email address" name="email" class="mail">
<input type="hidden" value="technogadge" name="uri"><input type="hidden" name="loc" value="en_US"><input type="submit" value="Subscribe" class="sub">
</form>
</div>
<!-- AddThis Button BEGIN -->
<a class="addthis_button" href="http://www.addthis.com/bookmark.php?v=300&amp;pubid=technogadge"><img src="http://s7.addthis.com/static/btn/v2/lg-share-en.gif" width="125" height="16" alt="Bookmark and Share" style="border:0"/></a>

<!-- AddThis Button END -->
<div class="clear"></div>

<h3 class="posts-list green">Recent Articles</h3>
<div id="recent">
<ul><li><a href="http://www.technogadge.com/jquery-mobile-free-mobile-framework/">jQuery Mobile &#8211; Framework for Creating Mobile Sites or Apps</a></li>
<li><a href="http://www.technogadge.com/timeto-jquery-countdown-timer-plugin/">TimeTo &#8211; jQuery Digital Clock Countdown Timer Plugin</a></li>
<li><a href="http://www.technogadge.com/fancy-fields-jquery-custom-forms-plugin/">Fancy Fields &#8211; jQuery Custom Form Elements Plugin</a></li>
<li><a href="http://www.technogadge.com/fluxbb-free-open-source-forum-script/">FluxBB &#8211; Free and Lightweight Forum Script</a></li>
<li><a href="http://www.technogadge.com/osclass-free-classifieds-script/">Create a Classified Ads Site with Osclass Free Classifieds Script</a></li>
</ul></div>

</div>
</aside>

</div>
<footer>
<div id="footer"><div id="footer-top"></div><ul><li><a title="About Us" href="http://www.technogadge.com/about" rel="nofollow">About</a></li><li><a title="Privacy" rel="nofollow" href="http://www.technogadge.com/privacy/">Privacy</a></li><li><a title="Contact Technogadge" rel="nofollow" href="http://www.technogadge.com/contact/">Contact</a></li></ul><p>Copyright &copy; 2008-16 <a href="http://www.technogadge.com">Technogadge.com</a>. All Rights Reserved.</p></div>
</footer>
</div>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-59225070-1', 'auto');
  ga('send', 'pageview');

</script>
<!-- Start of StatCounter Code for Default Guide -->
<script type="text/javascript">
//<![CDATA[
var sc_project=4118266; 
var sc_invisible=1; 
var sc_security="6d12acdb"; 
//]]>
</script>
<script type="text/javascript"
src="http://www.statcounter.com/counter/counter_xhtml.js"></script>
<noscript><div class="statcounter"><a title="create counter"
href="http://statcounter.com/free-hit-counter/"
class="statcounter"><img class="statcounter"
src="http://c.statcounter.com/4118266/0/6d12acdb/1/"
alt="create counter" /></a></div></noscript>
<!-- End of StatCounter Code for Default Guide -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=technogadge" async="async"></script>
</body>
</html>